import express from 'express';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

// Session store in memory (map of sessionId -> userId)
const sessions = new Map<string, { userId: string; role: string; email: string; expiresAt: number }>();

// Database file path
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'clinic.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial Database Seed
interface User {
  id: string;
  email: string;
  passwordHash: string;
  role: string;
  displayName: string;
}

interface Branch {
  id: string;
  nameAr: string;
  nameEn: string;
  addressAr: string;
  addressEn: string;
  city: string;
  governorate: string;
  phone: string;
  whatsapp: string;
  googleMapsUrl: string;
  openingHours: string;
  isActive: boolean;
  isVerified: boolean;
}

interface Service {
  id: string;
  nameAr: string;
  nameEn: string;
  nameFr: string;
  nameDe: string;
  nameTr: string;
  descAr: string;
  descEn: string;
  descFr: string;
  descDe: string;
  descTr: string;
  imageUrl: string;
  price: string;
  durationMinutes: number;
  isActive: boolean;
  displayOrder: number;
}

interface Appointment {
  id: string;
  patientName: string;
  patientPhone: string;
  branchId: string;
  serviceId: string;
  appointmentDate: string; // YYYY-MM-DD
  startTime: string; // HH:MM
  endTime: string; // HH:MM
  status: 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled' | 'No-show';
  patientMessage?: string;
  privacyConsent: boolean;
  privateAdminNotes?: string;
  createdAt: string;
}

interface GalleryImage {
  id: string;
  imageUrl: string;
  altAr: string;
  altEn: string;
  category: string;
  displayOrder: number;
  isActive: boolean;
}

interface SiteSettings {
  heroTitleAr: string;
  heroSubtitleAr: string;
  doctorBioAr: string;
  announcementAr: string;
}

interface DatabaseSchema {
  users: User[];
  branches: Branch[];
  services: Service[];
  appointments: Appointment[];
  gallery: GalleryImage[];
  settings: SiteSettings;
}

function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

const defaultDb: DatabaseSchema = {
  users: [
    {
      id: 'admin-1',
      email: process.env.ADMIN_EMAIL || 'admin@ibtisama.com',
      passwordHash: hashPassword(process.env.ADMIN_PASSWORD || 'admin123'),
      role: 'admin',
      displayName: 'دكتور فؤاد أحمد برعاص'
    }
  ],
  branches: [
    {
      id: 'branch-qutur',
      nameAr: 'فرع قطور (الرئيسي)',
      nameEn: 'Qutur Branch (Main)',
      addressAr: 'ميدان الساعة، قطور - طنطا، مدينة قطور، محافظة الغربية',
      addressEn: 'Al-Saa Square, Qutur - Tanta, Gharbia Governorate',
      city: 'قطور',
      goverrorate: 'الغربية',
      phone: '01129207375',
      whatsapp: '201129207375',
      googleMapsUrl: 'https://maps.google.com/?q=Qutur+Gharbia+Egypt',
      openingHours: 'السبت - الخميس: 1:00 ظهراً - 10:00 مساءً (الجمعة مغلق)',
      isActive: true,
      isVerified: true
    },
    {
      id: 'branch-damietta',
      nameAr: 'فرع دمياط',
      nameEn: 'Damietta Branch',
      addressAr: 'دمياط - كورنيش النيل (قيد التأكيد النهائي)',
      addressEn: 'Damietta - Nile Corniche (Pending Final Verification)',
      city: 'دمياط',
      goverrorate: 'دمياط',
      phone: '01129207375',
      whatsapp: '201129207375',
      googleMapsUrl: 'https://maps.google.com/?q=Damietta+Egypt',
      openingHours: 'يومياً ما عدا الجمعة (تواصل لتأكيد المواعيد)',
      isActive: true,
      isVerified: false
    }
  ],
  services: [
    {
      id: 'srv-implants',
      nameAr: 'زراعة الأسنان',
      nameEn: 'Dental Implants',
      nameFr: 'Implants Dentaires',
      nameDe: 'Zahnimplantate',
      nameTr: 'Diş İmplantları',
      descAr: 'تعويض الأسنان المفقودة بجذور تيتانيوم متينة وآمنة وبأحدث تقنيات الزراعة العالمية.',
      descEn: 'Replace missing teeth with durable titanium roots and state-of-the-art implant techniques.',
      descFr: 'Remplacez les dents manquantes par des racines en titane durables.',
      descDe: 'Ersetzen Sie fehlende Zähne durch langlebige Titanimplantate.',
      descTr: 'Eksik dişleri dayanıklı titanyum köklerle değiştirin.',
      imageUrl: 'https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=800&q=80',
      price: 'تواصل لمعرفة السعر',
      durationMinutes: 60,
      isActive: true,
      displayOrder: 1
    },
    {
      id: 'srv-whitening',
      nameAr: 'تبييض الأسنان',
      nameEn: 'Teeth Whitening',
      nameFr: 'Blanchiment Dentaire',
      nameDe: 'Zahnaufhellung',
      nameTr: 'Diş Beyazlatma',
      descAr: 'استعادة بريق وابتسامة بيضاء ناصعة بأحدث تقنيات الليزر الآمنة على ميناء الأسنان.',
      descEn: 'Restore your bright white smile using safe, advanced laser whitening technology.',
      descFr: 'Retrouvez un sourire éclatant grâce au blanchiment laser.',
      descDe: 'Stellen Sie Ihr strahlendes Lächeln mit Laserbleaching wieder her.',
      descTr: 'Gelişmiş lazer teknolojisiyle parlak beyaz gülüşünüzü geri kazanın.',
      imageUrl: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80',
      price: 'تواصل لمعرفة السعر',
      durationMinutes: 45,
      isActive: true,
      displayOrder: 2
    },
    {
      id: 'srv-ortho',
      nameAr: 'تقويم الأسنان',
      nameEn: 'Orthodontics',
      nameFr: 'Orthodontie',
      nameDe: 'Kieferorthopädie',
      nameTr: 'Ortodonti',
      descAr: 'إصلاح اعوجاج الأسنان وتطابق الإطباق للوصول إلى ابتسامة مثالية ومثالية الوظيفة.',
      descEn: 'Correct teeth alignment and bite occlusion for a perfectly balanced smile.',
      descFr: 'Corrigez l alignement des dents et l occlusion pour un sourire parfait.',
      descDe: 'Korrigieren Sie Zahnfehlstellungen für ein perfektes Lächeln.',
      descTr: 'Mükemmel bir gülüş için diş hizalamasını ve kapanışını düzeltin.',
      imageUrl: 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?auto=format&fit=crop&w=800&q=80',
      price: 'تواصل لمعرفة السعر',
      durationMinutes: 45,
      isActive: true,
      displayOrder: 3
    },
    {
      id: 'srv-rootcanal',
      nameAr: 'علاج وحشو العصب',
      nameEn: 'Root Canal Treatment',
      nameFr: 'Traitement de Canal',
      nameDe: 'Wurzelbehandlung',
      nameTr: 'Kanal Tedavisi',
      descAr: 'إزالة الالتهابات وتخليصك من الألم نهائياً بأحدث أجهزة الروتاري وبدون ألم.',
      descEn: 'Remove infection and eliminate pain with advanced painless rotary endodontics.',
      descFr: 'Éliminez l infection et la douleur avec des techniques endodontiques modernes.',
      descDe: 'Beseitigen Sie Infektionen und Schmerzen mit modernen Endodontie-Geräten.',
      descTr: 'Gelişmiş döner endodonti cihazlarıyla enfeksiyonu ve ağrıyı ortadan kaldırın.',
      imageUrl: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=800&q=80',
      price: 'تواصل لمعرفة السعر',
      durationMinutes: 60,
      isActive: true,
      displayOrder: 4
    },
    {
      id: 'srv-fillings',
      nameAr: 'الحشو التجميلي العادي',
      nameEn: 'Regular & Cosmetic Fillings',
      nameFr: 'Obturations Esthétiques',
      nameDe: 'Ästhetische Füllungen',
      nameTr: 'Estetik Dolgular',
      descAr: 'حشوات ضوئية تجميلية مطابقة للون الأسنان الطبيعية لعلاج التسوس وإعادة ترميم السن.',
      descEn: 'Tooth-colored composite fillings to repair cavities and restore natural appearance.',
      descFr: 'Obturations en composite de la couleur des dents pour réparer les caries.',
      descDe: 'Zahnfarbene Kompositfüllungen zur Kariesbehandlung und Wiederherstellung.',
      descTr: 'Çürükleri tedavi etmek ve doğal görünümü geri kazandırmak için kompozit dolgular.',
      imageUrl: 'https://images.unsplash.com/photo-1571772996211-2f0c6973722a?auto=format&fit=crop&w=800&q=80',
      price: 'تواصل لمعرفة السعر',
      durationMinutes: 30,
      isActive: true,
      displayOrder: 5
    },
    {
      id: 'srv-surgery',
      nameAr: 'جراحة الفم والأسنان',
      nameEn: 'Oral Surgery',
      nameFr: 'Chirurgie Buccale',
      nameDe: 'Oralchirurgie',
      nameTr: 'Ağız Cerrahisi',
      descAr: 'خلع الأسنان المعقدة وجراحة ضرس العرس بمهارة وعناية فائقة لراحة المريض.',
      descEn: 'Complex tooth extractions and wisdom tooth surgery with expert care and comfort.',
      descFr: 'Extractions dentaires complexes et chirurgie des dents de sagesse.',
      descDe: 'Komplexe Zahnextraktionen und Weisheitszahnchirurgie mit fachmännischer Sorgfalt.',
      descTr: 'Uzman bakımı ve konforuyla karmaşık diş çekimleri ve yirmilik diş cerrahisi.',
      imageUrl: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80',
      price: 'تواصل لمعرفة السعر',
      durationMinutes: 45,
      isActive: true,
      displayOrder: 6
    }
  ],
  appointments: [],
  gallery: [
    {
      id: 'gal-1',
      imageUrl: 'https://images.unsplash.com/photo-1629909615184-74f495363b67?auto=format&fit=crop&w=800&q=80',
      altAr: 'عيادة الأسنان الحديثة',
      altEn: 'Modern dental clinic room',
      category: 'clinic',
      displayOrder: 1,
      isActive: true
    },
    {
      id: 'gal-2',
      imageUrl: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80',
      altAr: 'غرفة الكشف والتعقيم',
      altEn: 'Sterilization and examination room',
      category: 'clinic',
      displayOrder: 2,
      isActive: true
    },
    {
      id: 'gal-3',
      imageUrl: 'https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=800&q=80',
      altAr: 'أحدث أجهزة طب الأسنان',
      altEn: 'Advanced dental equipment',
      category: 'equipment',
      displayOrder: 3,
      isActive: true
    },
    {
      id: 'gal-4',
      imageUrl: 'https://images.unsplash.com/photo-1571772996211-2f0c6973722a?auto=format&fit=crop&w=800&q=80',
      altAr: 'منطقة الاستقبال المريحة',
      altEn: 'Comfortable waiting lounge',
      category: 'reception',
      displayOrder: 4,
      isActive: true
    }
  ],
  settings: {
    heroTitleAr: 'ابتسامتك تستحق أفضل عناية',
    heroSubtitleAr: 'رعاية متخصصة لأسنانك وابتسامتك في بيئة مريحة واحترافية بإشراف دكتور فؤاد أحمد برعاص.',
    doctorBioBioAr: 'استشاري جراحة وتجميل الفم والأسنان، بخبرة واسعة في تجميل وزراعة الأسنان وعلاج جذور الأسنان.',
    announcementAr: 'مرحباً بكم في عيادة ابتسامة. احجز موعدك أونلاين بكل سهولة.'
  }
};

function loadDb(): DatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (e) {
    console.error('Error loading DB, using default:', e);
  }
  saveDb(defaultDb);
  return defaultDb;
}

function saveDb(db: DatabaseSchema) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error saving DB:', e);
  }
}

let db = loadDb();

// Middleware to check authentication from cookie or header
app.use((req, res, next) => {
  const authHeader = req.headers.authorization;
  const cookieHeader = req.headers.cookie;
  let sessionId = '';

  if (authHeader && authHeader.startsWith('Bearer ')) {
    sessionId = authHeader.substring(7);
  } else if (cookieHeader) {
    const match = cookieHeader.match(/sessionId=([^;]+)/);
    if (match) sessionId = match[1];
  }

  if (sessionId && sessions.has(sessionId)) {
    const session = sessions.get(sessionId)!;
    if (session.expiresAt > Date.now()) {
      (req as any).user = session;
    } else {
      sessions.delete(sessionId);
    }
  }
  next();
});

// Public API routes
app.get('/api/branches', (req, res) => {
  res.json(db.branches.filter(b => b.isActive));
});

app.get('/api/services', (req, res) => {
  res.json(db.services.filter(s => s.isActive).sort((a, b) => a.displayOrder - b.displayOrder));
});

app.get('/api/gallery', (req, res) => {
  res.json(db.gallery.filter(g => g.isActive).sort((a, b) => a.displayOrder - b.displayOrder));
});

app.get('/api/settings', (req, res) => {
  res.json(db.settings);
});

// Book Appointment (Public) with server-side conflict check
app.post('/api/appointments', (req, res) => {
  const { patientName, patientPhone, branchId, serviceId, appointmentDate, startTime, patientMessage, privacyConsent } = req.body;

  if (!patientName || !patientPhone || !branchId || !serviceId || !appointmentDate || !startTime) {
    return res.status(400).json({ error: 'جميع الحقول الأساسية مطلوبة.' });
  }

  if (!privacyConsent) {
    return res.status(400).json({ error: 'يجب الموافقة على سياسة الخصوصية للمتابعة.' });
  }

  // Check if slot is already booked for this branch & date & time
  const conflict = db.appointments.find(
    app => app.branchId === branchId &&
           app.appointmentDate === appointmentDate &&
           app.startTime === startTime &&
           app.status !== 'Cancelled'
  );

  if (conflict) {
    return res.status(409).json({ error: 'هذا الموعد محجوز مسبقاً. يرجى اختيار موعد آخر.' });
  }

  const service = db.services.find(s => s.id === serviceId);
  const duration = service ? service.durationMinutes : 30;

  // Calculate end time
  const [hours, mins] = startTime.split(':').map(Number);
  const endTotalMins = hours * 60 + mins + duration;
  const endHours = Math.floor(endTotalMins / 60) % 24;
  const endMins = endTotalMins % 60;
  const endTime = `${String(endHours).padStart(2, '0')}:${String(endMins).padStart(2, '0')}`;

  const newAppt: Appointment = {
    id: 'apt-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
    patientName,
    patientPhone,
    branchId,
    serviceId,
    appointmentDate,
    startTime,
    endTime,
    status: 'Pending',
    patientMessage: patientMessage || '',
    privacyConsent: Boolean(privacyConsent),
    createdAt: new Date().toISOString()
  };

  db.appointments.push(newAppt);
  saveDb(db);

  res.status(201).json({ success: true, message: 'تم استلام طلب الموعد بنجاح. سنقوم بتأكيد موعدك قريباً.', appointment: newAppt });
});

// Auth Routes
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'البريد الإلكتروني وكلمة المرور مطلوبان.' });
  }

  const passHash = hashPassword(password);
  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.passwordHash === passHash);

  if (!user) {
    return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' });
  }

  const sessionId = crypto.randomBytes(32).toString('hex');
  sessions.set(sessionId, {
    userId: user.id,
    role: user.role,
    email: user.email,
    expiresAt: Date.now() + 24 * 60 * 60 * 1000 // 24 hours
  });

  res.setHeader('Set-Cookie', `sessionId=${sessionId}; Path=/; HttpOnly; SameSite=Strict`);
  res.json({ success: true, token: sessionId, user: { email: user.email, role: user.role, displayName: user.displayName } });
});

app.post('/api/auth/logout', (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    sessions.delete(authHeader.substring(7));
  }
  res.setHeader('Set-Cookie', 'sessionId=; Path=/; Max-Age=0');
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  const user = (req as any).user;
  if (!user) {
    return res.status(401).json({ error: 'غير مسجل الدخول' });
  }
  const dbUser = db.users.find(u => u.id === user.userId);
  res.json({ email: user.email, role: user.role, displayName: dbUser?.displayName || 'مسؤول النظام' });
});

// Admin Middleware protection
function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const user = (req as any).user;
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'غير مصرح لك بالوصول لهذه المنطقة.' });
  }
  next();
}

// Admin API Routes
app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const total = db.appointments.length;
  const pending = db.appointments.filter(a => a.status === 'Pending').length;
  const confirmed = db.appointments.filter(a => a.status === 'Confirmed').length;
  const today = new Date().toISOString().split('T')[0];
  const todayCount = db.appointments.filter(a => a.appointmentDate === today).length;
  const cancelled = db.appointments.filter(a => a.status === 'Cancelled').length;

  const branchStats = db.branches.map(b => ({
    branchId: b.id,
    branchName: b.nameAr,
    count: db.appointments.filter(a => a.branchId === b.id).length
  }));

  res.json({
    total,
    pending,
    confirmed,
    todayCount,
    cancelled,
    branchStats
  });
});

app.get('/api/admin/appointments', requireAdmin, (req, res) => {
  res.json(db.appointments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
});

app.put('/api/admin/appointments/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  const { status, privateAdminNotes } = req.body;
  const appt = db.appointments.find(a => a.id === id);
  if (!appt) {
    return res.status(404).json({ error: 'الموعد غير موجود.' });
  }

  if (status) appt.status = status;
  if (privateAdminNotes !== undefined) appt.privateAdminNotes = privateAdminNotes;

  saveDb(db);
  res.json({ success: true, appointment: appt });
});

app.delete('/api/admin/appointments/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  db.appointments = db.appointments.filter(a => a.id !== id);
  saveDb(db);
  res.json({ success: true });
});

// Branches CRUD
app.get('/api/admin/branches', requireAdmin, (req, res) => {
  res.json(db.branches);
});

app.post('/api/admin/branches', requireAdmin, (req, res) => {
  const newBranch: Branch = {
    id: 'branch-' + Date.now(),
    ...req.body
  };
  db.branches.push(newBranch);
  saveDb(db);
  res.status(201).json({ success: true, branch: newBranch });
});

app.put('/api/admin/branches/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  const idx = db.branches.findIndex(b => b.id === id);
  if (idx === -1) return res.status(404).json({ error: 'الفرع غير موجود.' });
  db.branches[idx] = { ...db.branches[idx], ...req.body, id };
  saveDb(db);
  res.json({ success: true, branch: db.branches[idx] });
});

app.delete('/api/admin/branches/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  db.branches = db.branches.filter(b => b.id !== id);
  saveDb(db);
  res.json({ success: true });
});

// Services CRUD
app.get('/api/admin/services', requireAdmin, (req, res) => {
  res.json(db.services);
});

app.post('/api/admin/services', requireAdmin, (req, res) => {
  const newService: Service = {
    id: 'srv-' + Date.now(),
    ...req.body
  };
  db.services.push(newService);
  saveDb(db);
  res.status(201).json({ success: true, service: newService });
});

app.put('/api/admin/services/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  const idx = db.services.findIndex(s => s.id === id);
  if (idx === -1) return res.status(404).json({ error: 'الخدمة غير موجودة.' });
  db.services[idx] = { ...db.services[idx], ...req.body, id };
  saveDb(db);
  res.json({ success: true, service: db.services[idx] });
});

app.delete('/api/admin/services/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  db.services = db.services.filter(s => s.id !== id);
  saveDb(db);
  res.json({ success: true });
});

// Gallery CRUD
app.get('/api/admin/gallery', requireAdmin, (req, res) => {
  res.json(db.gallery);
});

app.post('/api/admin/gallery', requireAdmin, (req, res) => {
  const item: GalleryImage = {
    id: 'gal-' + Date.now(),
    ...req.body
  };
  db.gallery.push(item);
  saveDb(db);
  res.status(201).json({ success: true, item });
});

app.delete('/api/admin/gallery/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  db.gallery = db.gallery.filter(g => g.id !== id);
  saveDb(db);
  res.json({ success: true });
});

// Settings CRUD
app.get('/api/admin/settings', requireAdmin, (req, res) => {
  res.json(db.settings);
});

app.put('/api/admin/settings', requireAdmin, (req, res) => {
  db.settings = { ...db.settings, ...req.body };
  saveDb(db);
  res.json({ success: true, settings: db.settings });
});

// Vite dev integration
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true }
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`Ibtisama Dental Clinic server running on http://localhost:${PORT}`);
  });
}

startServer();
