export type Language = 'ar' | 'en' | 'fr' | 'de' | 'tr';

export interface Branch {
  id: string;
  nameAr: string;
  nameEn: string;
  addressAr: string;
  addressEn: string;
  city: string;
  governorate: string;
  phone: string;
  whatsapp: string;
  googleMapsUrl: string;
  openingHours: string;
  isActive: boolean;
  isVerified: boolean;
}

export interface Service {
  id: string;
  nameAr: string;
  nameEn: string;
  nameFr: string;
  nameDe: string;
  nameTr: string;
  descAr: string;
  descEn: string;
  descFr: string;
  descDe: string;
  descTr: string;
  imageUrl: string;
  price: string;
  durationMinutes: number;
  isActive: boolean;
  displayOrder: number;
}

export interface Appointment {
  id: string;
  patientName: string;
  patientPhone: string;
  branchId: string;
  serviceId: string;
  appointmentDate: string;
  startTime: string;
  endTime: string;
  status: 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled' | 'No-show';
  patientMessage?: string;
  privacyConsent: boolean;
  privateAdminNotes?: string;
  createdAt: string;
}

export interface GalleryImage {
  id: string;
  imageUrl: string;
  altAr: string;
  altEn: string;
  category: string;
  displayOrder: number;
  isActive: boolean;
}

export interface SiteSettings {
  heroTitleAr: string;
  heroSubtitleAr: string;
  doctorBioAr: string;
  announcementAr: string;
}
