import React, { useState, useEffect } from 'react';
import { Language } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import TrustSection from './components/TrustSection';
import FeaturedServices from './components/FeaturedServices';
import DoctorProfile from './components/DoctorProfile';
import BranchesSection from './components/BranchesSection';
import GallerySection from './components/GallerySection';
import ContactPage from './components/ContactPage';
import Footer from './components/Footer';
import BookingModal from './components/BookingModal';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';
import { MessageCircle } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [activePage, setActivePage] = useState<string>('home');
  const [bookingModalOpen, setBookingModalOpen] = useState<boolean>(false);
  const [bookingServiceId, setBookingServiceId] = useState<string | undefined>(undefined);
  const [adminToken, setAdminToken] = useState<string>(localStorage.getItem('adminToken') || '');

  // Update HTML dir attribute when language changes
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Check window hash for private admin access
  useEffect(() => {
    const handleHash = () => {
      if (window.location.hash === '#admin') {
        setActivePage('admin');
      }
    };
    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const handleOpenBookingWithService = (serviceId?: string) => {
    setBookingServiceId(serviceId);
    setBookingModalOpen(true);
  };

  const handleAdminLoginSuccess = (token: string) => {
    localStorage.setItem('adminToken', token);
    setAdminToken(token);
    setActivePage('admin-dashboard');
  };

  const handleAdminLogout = () => {
    localStorage.removeItem('adminToken');
    setAdminToken('');
    setActivePage('home');
  };

  // If on admin page
  if (activePage === 'admin') {
    if (adminToken) {
      return <AdminDashboard lang={lang} onLogout={handleAdminLogout} onBackToHome={() => setActivePage('home')} />;
    }
    return <AdminLogin lang={lang} onLoginSuccess={handleAdminLoginSuccess} onBackToHome={() => setActivePage('home')} />;
  }

  if (activePage === 'admin-dashboard') {
    return <AdminDashboard lang={lang} onLogout={handleAdminLogout} onBackToHome={() => setActivePage('home')} />;
  }

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-teal-100 selection:text-teal-900">
      
      {/* Top Header */}
      <Header
        lang={lang}
        setLang={setLang}
        activePage={activePage}
        setActivePage={setActivePage}
        onOpenBooking={() => handleOpenBookingWithService()}
      />

      {/* Main Pages Content */}
      <main className="flex-1">
        {activePage === 'home' && (
          <>
            <Hero
              lang={lang}
              onOpenBooking={() => handleOpenBookingWithService()}
              onExploreServices={() => setActivePage('services')}
            />
            <TrustSection lang={lang} />
            <FeaturedServices
              lang={lang}
              onOpenBookingWithService={handleOpenBookingWithService}
            />
            <DoctorProfile
              lang={lang}
              onOpenBooking={() => handleOpenBookingWithService()}
            />
            <BranchesSection lang={lang} />
            <GallerySection lang={lang} />
          </>
        )}

        {activePage === 'doctor' && (
          <DoctorProfile
            lang={lang}
            onOpenBooking={() => handleOpenBookingWithService()}
          />
        )}

        {activePage === 'services' && (
          <FeaturedServices
            lang={lang}
            onOpenBookingWithService={handleOpenBookingWithService}
          />
        )}

        {activePage === 'branches' && (
          <BranchesSection lang={lang} />
        )}

        {activePage === 'gallery' && (
          <GallerySection lang={lang} />
        )}

        {activePage === 'contact' && (
          <ContactPage lang={lang} />
        )}
      </main>

      {/* Footer */}
      <Footer lang={lang} setActivePage={setActivePage} />

      {/* Booking Modal */}
      <BookingModal
        lang={lang}
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        initialServiceId={bookingServiceId}
      />

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/201129207375?text=%Dمرحباً%D،%20أرغب%20بالاستفسار%20عن%20المواعيد%20في%20عيادة%20ابتسامة"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="WhatsApp"
        className="fixed bottom-6 end-6 z-40 w-14 h-14 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full flex items-center justify-center shadow-2xl transition-transform hover:scale-110"
      >
        <MessageCircle className="w-7 h-7" />
      </a>

    </div>
  );
}
