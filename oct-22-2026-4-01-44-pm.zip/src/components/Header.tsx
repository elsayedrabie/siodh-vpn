import React, { useState } from 'react';
import { Language } from '../types';
import { getTranslation } from '../i18n';
import { Menu, X, Globe, Calendar, ShieldCheck, Stethoscope } from 'lucide-react';

interface HeaderProps {
  lang: Language;
  setLang: (l: Language) => void;
  activePage: string;
  setActivePage: (p: string) => void;
  onOpenBooking: () => void;
}

export default function Header({ lang, setLang, activePage, setActivePage, onOpenBooking }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const languages: { code: Language; label: string }[] = [
    { code: 'ar', label: 'العربية' },
    { code: 'en', label: 'English' },
    { code: 'fr', label: 'Français' },
    { code: 'de', label: 'Deutsch' },
    { code: 'tr', label: 'Türkçe' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          
          {/* Zone 1: Single text element Brand wordmark */}
          <div 
            onClick={() => setActivePage('home')}
            className="flex items-center gap-3 cursor-pointer shrink-0"
          >
            <div className="w-11 h-11 rounded-xl bg-teal-700 text-white flex items-center justify-center shadow-md shadow-teal-700/20">
              <Stethoscope className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-900 block font-serif">
                {getTranslation(lang, 'brandName')}
              </span>
              <span className="text-xs text-teal-700 font-medium tracking-wide block">
                {getTranslation(lang, 'brandSubtitle')}
              </span>
            </div>
          </div>

          {/* Zone 2: 4-5 clean single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-700">
            <button 
              onClick={() => setActivePage('home')} 
              className={`hover:text-teal-700 transition-colors whitespace-nowrap shrink-0 ${activePage === 'home' ? 'text-teal-700 font-semibold' : ''}`}
            >
              {getTranslation(lang, 'navHome')}
            </button>
            <button 
              onClick={() => setActivePage('doctor')} 
              className={`hover:text-teal-700 transition-colors whitespace-nowrap shrink-0 ${activePage === 'doctor' ? 'text-teal-700 font-semibold' : ''}`}
            >
              {getTranslation(lang, 'navDoctor')}
            </button>
            <button 
              onClick={() => setActivePage('services')} 
              className={`hover:text-teal-700 transition-colors whitespace-nowrap shrink-0 ${activePage === 'services' ? 'text-teal-700 font-semibold' : ''}`}
            >
              {getTranslation(lang, 'navServices')}
            </button>
            <button 
              onClick={() => setActivePage('branches')} 
              className={`hover:text-teal-700 transition-colors whitespace-nowrap shrink-0 ${activePage === 'branches' ? 'text-teal-700 font-semibold' : ''}`}
            >
              {getTranslation(lang, 'navBranches')}
            </button>
            <button 
              onClick={() => setActivePage('gallery')} 
              className={`hover:text-teal-700 transition-colors whitespace-nowrap shrink-0 ${activePage === 'gallery' ? 'text-teal-700 font-semibold' : ''}`}
            >
              {getTranslation(lang, 'navGallery')}
            </button>
            <button 
              onClick={() => setActivePage('contact')} 
              className={`hover:text-teal-700 transition-colors whitespace-nowrap shrink-0 ${activePage === 'contact' ? 'text-teal-700 font-semibold' : ''}`}
            >
              {getTranslation(lang, 'navContact')}
            </button>
          </nav>

          {/* Zone 3: Language Selector & Primary CTA Action */}
          <div className="flex items-center gap-4 shrink-0">
            {/* Language dropdown */}
            <div className="relative group">
              <div className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-slate-100 text-slate-700 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-200 transition-colors">
                <Globe className="w-3.5 h-3.5 text-teal-700" />
                <span className="uppercase">{lang}</span>
              </div>
              <div className="absolute right-0 mt-1 w-36 bg-white border border-slate-200 rounded-xl shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all py-1 z-50">
                {languages.map((item) => (
                  <button
                    key={item.code}
                    onClick={() => setLang(item.code)}
                    className={`w-full text-start px-4 py-2 text-xs font-medium hover:bg-teal-50 hover:text-teal-700 transition-colors ${lang === item.code ? 'text-teal-700 font-bold bg-teal-50/50' : 'text-slate-700'}`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Primary CTA */}
            <button
              onClick={onOpenBooking}
              className="hidden sm:flex items-center gap-2 px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white text-sm font-semibold rounded-xl shadow-md shadow-teal-700/20 transition-all whitespace-nowrap shrink-0"
            >
              <Calendar className="w-4 h-4" />
              <span>{getTranslation(lang, 'bookAppointment')}</span>
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-700 hover:text-teal-700"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-6 py-6 space-y-4 shadow-xl">
          <div className="flex flex-col space-y-3 font-medium text-slate-700">
            <button 
              onClick={() => { setActivePage('home'); setMobileMenuOpen(false); }}
              className="text-start py-2 hover:text-teal-700"
            >
              {getTranslation(lang, 'navHome')}
            </button>
            <button 
              onClick={() => { setActivePage('doctor'); setMobileMenuOpen(false); }}
              className="text-start py-2 hover:text-teal-700"
            >
              {getTranslation(lang, 'navDoctor')}
            </button>
            <button 
              onClick={() => { setActivePage('services'); setMobileMenuOpen(false); }}
              className="text-start py-2 hover:text-teal-700"
            >
              {getTranslation(lang, 'navServices')}
            </button>
            <button 
              onClick={() => { setActivePage('branches'); setMobileMenuOpen(false); }}
              className="text-start py-2 hover:text-teal-700"
            >
              {getTranslation(lang, 'navBranches')}
            </button>
            <button 
              onClick={() => { setActivePage('gallery'); setMobileMenuOpen(false); }}
              className="text-start py-2 hover:text-teal-700"
            >
              {getTranslation(lang, 'navGallery')}
            </button>
            <button 
              onClick={() => { setActivePage('contact'); setMobileMenuOpen(false); }}
              className="text-start py-2 hover:text-teal-700"
            >
              {getTranslation(lang, 'navContact')}
            </button>
          </div>
          <div className="pt-4 border-t border-slate-100 flex flex-col gap-3">
            <button
              onClick={() => { onOpenBooking(); setMobileMenuOpen(false); }}
              className="w-full flex items-center justify-center gap-2 py-3 bg-teal-700 text-white font-semibold rounded-xl shadow-md"
            >
              <Calendar className="w-4 h-4" />
              <span>{getTranslation(lang, 'bookAppointment')}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
