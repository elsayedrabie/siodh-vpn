import React, { useEffect, useState } from 'react';
import { Language, Branch } from '../types';
import { getTranslation } from '../i18n';
import { MapPin, Phone, Clock, ExternalLink, MessageCircle } from 'lucide-react';

interface BranchesSectionProps {
  lang: Language;
}

export default function BranchesSection({ lang }: BranchesSectionProps) {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/branches')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setBranches(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load branches:', err);
        setLoading(false);
      });
  }, []);

  const isAr = lang === 'ar';

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 font-serif">
            {getTranslation(lang, 'branchesTitle')}
          </h2>
          <p className="text-slate-600">
            {getTranslation(lang, 'branchesSubtitle')}
          </p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-500">جاري تحميل الفروع...</div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {branches.map((branch) => {
              const name = isAr ? branch.nameAr : branch.nameEn;
              const address = isAr ? branch.addressAr : branch.addressEn;

              return (
                <div key={branch.id} className="bg-slate-50 border border-slate-200/80 rounded-2xl p-8 shadow-xs flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <h3 className="text-xl font-bold text-slate-900 font-serif">{name}</h3>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${branch.isVerified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                        {branch.isVerified ? (isAr ? 'فرع معتمد' : 'Verified Branch') : (isAr ? 'قيد التأكيد' : 'Pending Verification')}
                      </span>
                    </div>

                    <div className="space-y-3 text-slate-600 text-sm">
                      <div className="flex items-start gap-3">
                        <MapPin className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
                        <span>{address}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Phone className="w-5 h-5 text-teal-700 shrink-0" />
                        <span className="font-mono font-semibold" dir="ltr">{branch.phone}</span>
                      </div>
                      <div className="flex items-start gap-3">
                        <Clock className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
                        <span>{branch.openingHours}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-slate-200">
                    <a
                      href={branch.googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold rounded-xl transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>{getTranslation(lang, 'directions')}</span>
                    </a>

                    {branch.whatsapp && (
                      <a
                        href={`https://wa.me/${branch.whatsapp}?text=${encodeURIComponent(isAr ? 'مرحباً، أرغب بالاستفسار عن المواعيد في عيادة ابتسامة.' : 'Hello, I would like to inquire about appointments at Ibtisama Clinic.')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl transition-colors shadow-sm"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>{getTranslation(lang, 'whatsappChat')}</span>
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
