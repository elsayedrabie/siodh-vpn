import React from 'react';
import { Language } from '../types';
import { getTranslation } from '../i18n';
import { Award, CheckCircle, Stethoscope, UserCheck } from 'lucide-react';

interface DoctorProfileProps {
  lang: Language;
  onOpenBooking: () => void;
}

export default function DoctorProfile({ lang, onOpenBooking }: DoctorProfileProps) {
  const isAr = lang === 'ar';

  return (
    <section className="py-24 bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Doctor Portrait */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md">
              <div className="absolute -inset-4 bg-teal-100 rounded-3xl -z-10 transform -rotate-2"></div>
              <img
                src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=800&q=80"
                alt="Dr. Fouad Ahmed Baraas"
                className="rounded-2xl shadow-xl w-full object-cover h-[500px]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-6 start-6 end-6 bg-white/95 backdrop-blur-md p-6 rounded-2xl shadow-lg border border-slate-100">
                <span className="text-teal-700 text-xs font-bold block mb-1">
                  {getTranslation(lang, 'doctorRole')}
                </span>
                <h3 className="text-xl font-bold text-slate-900 font-serif">
                  {getTranslation(lang, 'doctorTitle')}
                </h3>
              </div>
            </div>
          </div>

          {/* Doctor Info */}
          <div className="lg:col-span-7 space-y-6 text-start">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-50 text-teal-800 text-xs font-semibold">
              <Stethoscope className="w-4 h-4 text-teal-700" />
              <span>{isAr ? 'الطبيب المعالج' : 'Lead Specialist'}</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 font-serif">
              {getTranslation(lang, 'doctorTitle')}
            </h2>

            <p className="text-lg text-slate-700 font-medium">
              {getTranslation(lang, 'doctorRole')}
            </p>

            <p className="text-slate-600 leading-relaxed">
              {getTranslation(lang, 'doctorBio')}
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3 text-slate-700">
                <CheckCircle className="w-5 h-5 text-teal-700 shrink-0" />
                <span>{isAr ? 'خبرة واسعة في زراعة وتجميل الأسنان وحراحات الفم الدقيقة' : 'Extensive experience in dental implants and cosmetic dentistry'}</span>
              </div>
              <div className="flex items-center gap-3 text-slate-700">
                <CheckCircle className="w-5 h-5 text-teal-700 shrink-0" />
                <span>{isAr ? 'استخدام أحدث أجهزة التشخيص والتعقيم المتقدمة' : 'Using state-of-the-art diagnostic and sterilization equipment'}</span>
              </div>
              <div className="flex items-center gap-3 text-slate-700">
                <CheckCircle className="w-5 h-5 text-teal-700 shrink-0" />
                <span>{isAr ? 'حرص كامل على توفير بيئة علاجية هادئة وخالية من الألم' : 'Dedicated to providing a calm and pain-free treatment environment'}</span>
              </div>
            </div>

            <div className="pt-6">
              <button
                onClick={onOpenBooking}
                className="px-8 py-4 bg-teal-700 hover:bg-teal-800 text-white font-semibold rounded-xl shadow-md transition-all text-base"
              >
                {getTranslation(lang, 'bookAppointment')}
              </button>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
