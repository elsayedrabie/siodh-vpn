import React from 'react';
import { Language } from '../types';
import { getTranslation } from '../i18n';
import { MapPin, Phone, Clock, Mail, MessageCircle, Send } from 'lucide-react';

interface ContactPageProps {
  lang: Language;
}

export default function ContactPage({ lang }: ContactPageProps) {
  const isAr = lang === 'ar';

  return (
    <div className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <h1 className="text-4xl font-bold text-slate-900 font-serif">
            {getTranslation(lang, 'contactTitle')}
          </h1>
          <p className="text-slate-600">
            {getTranslation(lang, 'contactSubtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Details */}
          <div className="space-y-8">
            <div className="bg-slate-50 border border-slate-200/80 rounded-3xl p-8 space-y-6">
              <h3 className="text-2xl font-bold text-slate-900 font-serif">
                {isAr ? 'فروع عيادة ابتسامة' : 'Ibtisama Clinic Branches'}
              </h3>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-teal-50 text-teal-700 rounded-xl flex items-center justify-center shrink-0">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">{getTranslation(lang, 'quturBranchTitle')}</h4>
                    <p className="text-sm text-slate-600 mt-1">ميدان الساعة، قطور - طنطا، مدينة قطور، محافظة الغربية</p>
                    <p className="text-sm font-semibold text-teal-700 mt-2 font-mono" dir="ltr">01129207375</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-teal-50 text-teal-700 rounded-xl flex items-center justify-center shrink-0">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">{getTranslation(lang, 'damiettaBranchTitle')}</h4>
                    <p className="text-sm text-slate-600 mt-1">دمياط - كورنيش النيل (قيد التأكيد النهائي)</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Inquiry Form */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-3xl p-8 space-y-6">
            <h3 className="text-2xl font-bold text-slate-900 font-serif">
              {isAr ? 'أرسل لنا رسالة مباشرة' : 'Send Us a Direct Message'}
            </h3>

            <form onSubmit={e => { e.preventDefault(); alert(isAr ? 'تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.' : 'Message sent successfully!'); }} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{getTranslation(lang, 'nameLabel')}</label>
                <input type="text" required className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{getTranslation(lang, 'phoneLabel')}</label>
                <input type="tel" required dir="ltr" className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white text-start" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{getTranslation(lang, 'messageLabel')}</label>
                <textarea rows={4} required className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm bg-white" />
              </div>
              <button
                type="submit"
                className="w-full py-4 bg-teal-700 hover:bg-teal-800 text-white font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>{isAr ? 'إرسال الرسالة' : 'Send Message'}</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
