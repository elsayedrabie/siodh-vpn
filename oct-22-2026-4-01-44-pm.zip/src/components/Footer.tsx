import React, { useState } from 'react';
import { Language } from '../types';
import { getTranslation } from '../i18n';
import { Stethoscope, X } from 'lucide-react';

interface FooterProps {
  lang: Language;
  setActivePage: (p: string) => void;
}

export default function Footer({ lang, setActivePage }: FooterProps) {
  const [modalType, setModalType] = useState<'privacy' | 'terms' | null>(null);
  const isAr = lang === 'ar';

  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-700 text-white flex items-center justify-center">
                <Stethoscope className="w-5 h-5" />
              </div>
              <div>
                <span className="text-lg font-bold text-white block font-serif">
                  {getTranslation(lang, 'brandName')}
                </span>
                <span className="text-xs text-teal-400 font-medium">
                  {getTranslation(lang, 'brandSubtitle')}
                </span>
              </div>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              {isAr ? 'رعاية متخصصة لأسنانك وابتسامتك في بيئة مريحة واحترافية بإشراف دكتور فؤاد أحمد برعاص.' : 'Specialized dental care led by Dr. Fouad Ahmed Baraas.'}
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm tracking-wide uppercase">
              {isAr ? 'روابط سريعة' : 'Quick Links'}
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li><button onClick={() => setActivePage('home')} className="hover:text-teal-400 transition-colors">{getTranslation(lang, 'navHome')}</button></li>
              <li><button onClick={() => setActivePage('doctor')} className="hover:text-teal-400 transition-colors">{getTranslation(lang, 'navDoctor')}</button></li>
              <li><button onClick={() => setActivePage('services')} className="hover:text-teal-400 transition-colors">{getTranslation(lang, 'navServices')}</button></li>
              <li><button onClick={() => setActivePage('branches')} className="hover:text-teal-400 transition-colors">{getTranslation(lang, 'navBranches')}</button></li>
            </ul>
          </div>

          {/* Branches */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm tracking-wide uppercase">
              {getTranslation(lang, 'navBranches')}
            </h4>
            <ul className="space-y-2.5 text-sm text-slate-400">
              <li>{getTranslation(lang, 'quturBranchTitle')}</li>
              <li>{getTranslation(lang, 'damiettaBranchTitle')}</li>
              <li className="font-mono text-teal-400 font-semibold" dir="ltr">01129207375</li>
            </ul>
          </div>

          {/* Legal */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm tracking-wide uppercase">
              {isAr ? 'السياسات القانونية' : 'Legal Policies'}
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li><button onClick={() => setModalType('privacy')} className="hover:text-teal-400 transition-colors">{getTranslation(lang, 'privacyPolicy')}</button></li>
              <li><button onClick={() => setModalType('terms')} className="hover:text-teal-400 transition-colors">{getTranslation(lang, 'termsOfUse')}</button></li>
            </ul>
          </div>

        </div>

        <div className="pt-8 border-t border-slate-800 text-center text-xs text-slate-500">
          <p>{getTranslation(lang, 'footerRights')}</p>
        </div>
      </div>

      {/* Privacy / Terms Modal */}
      {modalType && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-white text-slate-900 rounded-3xl max-w-2xl w-full p-8 relative space-y-6">
            <button onClick={() => setModalType(null)} className="absolute top-6 end-6 p-2 text-slate-400 hover:text-slate-700">
              <X className="w-5 h-5" />
            </button>
            <h3 className="text-2xl font-bold font-serif">
              {modalType === 'privacy' ? getTranslation(lang, 'privacyPolicy') : getTranslation(lang, 'termsOfUse')}
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              {modalType === 'privacy'
                ? (isAr ? 'نلتزم بحماية خصوصية بياناتك الطبية والشخصية. يتم استخدام بيانات حجز المواعيد حصرياً داخل العيادة للتواصل وتأكيد الحجوزات ولن يتم مشاركتها مع أي جهة خارجية.' : 'We are committed to protecting your privacy and medical data.')
                : (isAr ? 'استخدامك لموقع عيادة ابتسامة يخضع لشروط الاستخدام والسياسات الطبية المعمول بها في جمهورية مصر العربية.' : 'Your use of Ibtisama Clinic website is subject to our terms of use.')}
            </p>
            <button onClick={() => setModalType(null)} className="px-6 py-2.5 bg-teal-700 text-white text-sm font-semibold rounded-xl">
              {getTranslation(lang, 'close')}
            </button>
          </div>
        </div>
      )}
    </footer>
  );
}
