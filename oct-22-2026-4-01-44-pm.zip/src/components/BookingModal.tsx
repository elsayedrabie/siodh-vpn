import React, { useEffect, useState } from 'react';
import { Language, Branch, Service } from '../types';
import { getTranslation } from '../i18n';
import { X, Calendar, Clock, CheckCircle, AlertCircle, User, Phone, MapPin, Stethoscope, MessageSquare } from 'lucide-react';

interface BookingModalProps {
  lang: Language;
  isOpen: boolean;
  onClose: () => void;
  initialServiceId?: string;
}

export default function BookingModal({ lang, isOpen, onClose, initialServiceId }: BookingModalProps) {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [services, setServices] = useState<Service[]>([]);

  const [branchId, setBranchId] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [appointmentDate, setAppointmentDate] = useState('');
  const [startTime, setStartTime] = useState('10:00');
  const [patientMessage, setPatientMessage] = useState('');
  const [privacyConsent, setPrivacyConsent] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetch('/api/branches')
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data)) {
            setBranches(data);
            if (data.length > 0 && !branchId) setBranchId(data[0].id);
          }
        });

      fetch('/api/services')
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data)) {
            setServices(data);
            if (initialServiceId) {
              setServiceId(initialServiceId);
            } else if (data.length > 0) {
              setServiceId(data[0].id);
            }
          }
        });

      // Default date to tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setAppointmentDate(tomorrow.toISOString().split('T')[0]);
      setSuccess(false);
      setError('');
    }
  }, [isOpen, initialServiceId]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!patientName || !patientPhone || !branchId || !serviceId || !appointmentDate || !startTime) {
      setError(lang === 'ar' ? 'جميع الحقول الأساسية مطلوبة.' : 'All required fields must be filled.');
      return;
    }

    if (!privacyConsent) {
      setError(lang === 'ar' ? 'يجب الموافقة على سياسة الخصوصية للمتابعة.' : 'You must agree to the privacy policy.');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientName,
          patientPhone,
          branchId,
          serviceId,
          appointmentDate,
          startTime,
          patientMessage,
          privacyConsent
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'فشل الحجز');
      }

      setSuccess(true);
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء حجز الموعد. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  const timeSlots = ['10:00', '11:00', '12:00', '13:00', '14:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00'];
  const isAr = lang === 'ar';

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-8 shadow-2xl relative my-8">
        <button
          onClick={onClose}
          className="absolute top-6 end-6 p-2 text-slate-400 hover:text-slate-700 bg-slate-100 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {success ? (
          <div className="text-center py-12 space-y-6">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 font-serif">
              {isAr ? 'تم استلام طلب موعدك بنجاح' : 'Appointment Request Received'}
            </h3>
            <p className="text-slate-600 max-w-md mx-auto">
              {getTranslation(lang, 'bookingSuccess')}
            </p>
            <button
              onClick={onClose}
              className="px-8 py-3 bg-teal-700 hover:bg-teal-800 text-white font-semibold rounded-xl shadow-md transition-all"
            >
              {getTranslation(lang, 'close')}
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-50 text-teal-800 text-xs font-semibold">
                <Calendar className="w-3.5 h-3.5 text-teal-700" />
                <span>{getTranslation(lang, 'bookAppointment')}</span>
              </div>
              <h2 className="text-2xl font-bold text-slate-900 font-serif">
                {isAr ? 'احجز موعدك في عيادة ابتسامة' : 'Book Your Appointment'}
              </h2>
              <p className="text-sm text-slate-600">
                {isAr ? 'املأ البيانات أدناه وسيقوم فريق الاستقبال بتأكيد الموعد معك.' : 'Fill out the details below and our reception team will confirm.'}
              </p>
            </div>

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl flex items-center gap-3">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Patient Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-teal-700" />
                  <span>{getTranslation(lang, 'nameLabel')}</span>
                </label>
                <input
                  type="text"
                  required
                  value={patientName}
                  onChange={e => setPatientName(e.target.value)}
                  placeholder={isAr ? 'مثال: أحمد محمد علي' : 'Full Name'}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              {/* Phone Number */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-teal-700" />
                  <span>{getTranslation(lang, 'phoneLabel')}</span>
                </label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={patientPhone}
                  onChange={e => setPatientPhone(e.target.value)}
                  placeholder="01129207375"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 text-start"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Branch */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-teal-700" />
                  <span>{getTranslation(lang, 'branchLabel')}</span>
                </label>
                <select
                  value={branchId}
                  onChange={e => setBranchId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                >
                  {branches.map(b => (
                    <option key={b.id} value={b.id}>
                      {isAr ? b.nameAr : b.nameEn}
                    </option>
                  ))}
                </select>
              </div>

              {/* Service */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Stethoscope className="w-3.5 h-3.5 text-teal-700" />
                  <span>{getTranslation(lang, 'serviceLabel')}</span>
                </label>
                <select
                  value={serviceId}
                  onChange={e => setServiceId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                >
                  {services.map(s => (
                    <option key={s.id} value={s.id}>
                      {isAr ? s.nameAr : (s.nameEn || s.nameAr)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Date */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-teal-700" />
                  <span>{getTranslation(lang, 'dateLabel')}</span>
                </label>
                <input
                  type="date"
                  required
                  value={appointmentDate}
                  onChange={e => setAppointmentDate(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              {/* Time Slot */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-teal-700" />
                  <span>{getTranslation(lang, 'timeLabel')}</span>
                </label>
                <select
                  value={startTime}
                  onChange={e => setStartTime(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                >
                  {timeSlots.map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Optional message */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-teal-700" />
                <span>{getTranslation(lang, 'messageLabel')}</span>
              </label>
              <textarea
                rows={2}
                value={patientMessage}
                onChange={e => setPatientMessage(e.target.value)}
                placeholder={isAr ? 'اكتب تفاصيل إضافية أو الأعراض...' : 'Additional notes...'}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Privacy Consent */}
            <div className="flex items-start gap-3 pt-2">
              <input
                type="checkbox"
                id="privacy"
                required
                checked={privacyConsent}
                onChange={e => setPrivacyConsent(e.target.checked)}
                className="mt-1 w-4 h-4 text-teal-700 rounded border-slate-300 focus:ring-teal-500"
              />
              <label htmlFor="privacy" className="text-xs text-slate-600 leading-relaxed cursor-pointer">
                {getTranslation(lang, 'privacyConsent')}
              </label>
            </div>

            <div className="pt-4">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white font-semibold rounded-xl shadow-lg transition-all text-base"
              >
                {loading ? (isAr ? 'جاري إرسال الطلب...' : 'Submitting...') : getTranslation(lang, 'submitBooking')}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
