import React, { useEffect, useState } from 'react';
import { Language, Service } from '../types';
import { getTranslation } from '../i18n';
import { Calendar, ArrowRight, Sparkles } from 'lucide-react';

interface FeaturedServicesProps {
  lang: Language;
  onOpenBookingWithService?: (serviceId: string) => void;
}

export default function FeaturedServices({ lang, onOpenBookingWithService }: FeaturedServicesProps) {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/services')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setServices(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load services:', err);
        setLoading(false);
      });
  }, []);

  const isAr = lang === 'ar';

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-50 text-teal-800 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-teal-700" />
              <span>{isAr ? 'الخدمات الطبية' : 'Medical Services'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 font-serif">
              {getTranslation(lang, 'servicesTitle')}
            </h2>
            <p className="text-slate-600 max-w-xl">
              {getTranslation(lang, 'servicesSubtitle')}
            </p>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-500">جاري تحميل الخدمات...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => {
              const name = isAr ? service.nameAr : (service.nameEn || service.nameAr);
              const desc = isAr ? service.descAr : (service.descEn || service.descAr);

              return (
                <div key={service.id} className="bg-slate-50 rounded-2xl overflow-hidden border border-slate-200/80 hover:shadow-xl transition-all flex flex-col justify-between group">
                  <div>
                    <div className="relative h-52 overflow-hidden">
                      <img
                        src={service.imageUrl}
                        alt={name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-4 start-4 bg-white/90 backdrop-blur-xs px-3 py-1 rounded-full text-xs font-bold text-teal-800 shadow-sm">
                        {service.price}
                      </div>
                    </div>
                    <div className="p-6 space-y-3">
                      <h3 className="text-xl font-bold text-slate-900 font-serif">{name}</h3>
                      <p className="text-sm text-slate-600 line-clamp-3 leading-relaxed">{desc}</p>
                    </div>
                  </div>
                  <div className="p-6 pt-0">
                    <button
                      onClick={() => onOpenBookingWithService && onOpenBookingWithService(service.id)}
                      className="w-full flex items-center justify-center gap-2 py-3 bg-teal-700 hover:bg-teal-800 text-white font-semibold rounded-xl shadow-md transition-all text-sm"
                    >
                      <Calendar className="w-4 h-4" />
                      <span>{getTranslation(lang, 'bookAppointment')}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
