import React, { useEffect, useState } from 'react';
import { Language, GalleryImage } from '../types';
import { getTranslation } from '../i18n';
import { Sparkles, X } from 'lucide-react';

interface GallerySectionProps {
  lang: Language;
}

export default function GallerySection({ lang }: GallerySectionProps) {
  const [gallery, setGallery] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  useEffect(() => {
    fetch('/api/gallery')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setGallery(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load gallery:', err);
        setLoading(false);
      });
  }, []);

  const isAr = lang === 'ar';

  return (
    <section className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-50 text-teal-800 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-teal-700" />
            <span>{isAr ? 'جولة مصورة' : 'Visual Tour'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 font-serif">
            {getTranslation(lang, 'galleryTitle')}
          </h2>
          <p className="text-slate-600">
            {getTranslation(lang, 'gallerySubtitle')}
          </p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-500">جاري تحميل الصور...</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {gallery.map((item) => {
              const alt = isAr ? item.altAr : item.altEn;
              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedImage(item)}
                  className="group relative h-64 rounded-2xl overflow-hidden cursor-pointer shadow-sm hover:shadow-xl transition-all bg-white border border-slate-200"
                >
                  <img
                    src={item.imageUrl}
                    alt={alt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                    <p className="text-white text-sm font-semibold">{alt}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Lightbox Modal */}
        {selectedImage && (
          <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-6 end-6 p-2 text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="max-w-4xl w-full text-center space-y-4">
              <img
                src={selectedImage.imageUrl}
                alt={isAr ? selectedImage.altAr : selectedImage.altEn}
                className="max-h-[80vh] mx-auto rounded-xl object-contain shadow-2xl"
                referrerPolicy="no-referrer"
              />
              <p className="text-white text-lg font-medium">
                {isAr ? selectedImage.altAr : selectedImage.altEn}
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
