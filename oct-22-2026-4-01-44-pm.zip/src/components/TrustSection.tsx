import React from 'react';
import { Language } from '../types';
import { ShieldCheck, HeartPulse, Clock, Sparkles } from 'lucide-react';

interface TrustSectionProps {
  lang: Language;
}

export default function TrustSection({ lang }: TrustSectionProps) {
  const principles = [
    {
      icon: <HeartPulse className="w-6 h-6 text-teal-700" />,
      titleAr: 'رعاية مخصصة للمريض',
      titleEn: 'Patient-Focused Care',
      descAr: 'نضع راحة المريض وصحته في المقام الأول مع خطة علاجية مصممة خصيصاً لحالته.',
      descEn: 'Putting patient comfort and health first with a tailored treatment plan.'
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-teal-700" />,
      titleAr: 'تعقيم بمعايير عالمية',
      titleEn: 'Global Sterilization Standards',
      descAr: 'أحدث أجهزة التعقيم وأنظمة مكافحة العدوى لضمان أقصى درجات الأمان الصحي.',
      descEn: 'Advanced sterilization devices and infection control for maximum safety.'
    },
    {
      icon: <Sparkles className="w-6 h-6 text-teal-700" />,
      titleAr: 'تقنيات طبية متقدمة',
      titleEn: 'Advanced Dental Technologies',
      descAr: 'استخدام أحدث تقنيات الليزر والأجهزة الرقمية لضمان دقة النتائج وسرعة الشفاء.',
      descEn: 'Using state-of-the-art laser and digital equipment for precise results.'
    },
    {
      icon: <Clock className="w-6 h-6 text-teal-700" />,
      titleAr: 'تنظيم دقيق للمواعيد',
      titleEn: 'Precise Appointment Organization',
      descAr: 'نظام مواعيد مرن ودقيق يضمن عدم الانتظار الطويل واحترام وقت كل مريض.',
      descEn: 'Flexible appointment system ensuring no long wait times.'
    }
  ];

  const isAr = lang === 'ar';

  return (
    <section className="py-20 bg-slate-50 border-y border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl font-bold text-slate-900 font-serif">
            {isAr ? 'لماذا تختار عيادة ابتسامة؟' : 'Why Choose Ibtisama Dental Clinic?'}
          </h2>
          <p className="text-slate-600">
            {isAr ? 'نلتزم بتقديم أعلى مستويات الرعاية الطبية والاحترافية في بيئة دافئة ومريحة.' : 'We are committed to delivering the highest standards of medical care in a warm and comfortable environment.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {principles.map((item, index) => (
            <div key={index} className="bg-white p-8 rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all">
              <div className="w-12 h-12 bg-teal-50 rounded-xl flex items-center justify-center mb-6">
                {item.icon}
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                {isAr ? item.titleAr : item.titleEn}
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                {isAr ? item.descAr : item.descEn}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
