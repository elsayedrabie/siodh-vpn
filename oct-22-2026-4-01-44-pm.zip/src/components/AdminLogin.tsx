import React, { useState } from 'react';
import { Language } from '../types';
import { getTranslation } from '../i18n';
import { ShieldCheck, Lock, Mail, AlertCircle, ArrowLeft } from 'lucide-react';

interface AdminLoginProps {
  lang: Language;
  onLoginSuccess: (token: string) => void;
  onBackToHome: () => void;
}

export default function AdminLogin({ lang, onLoginSuccess, onBackToHome }: AdminLoginProps) {
  const [email, setEmail] = useState('admin@ibtisama.com');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const isAr = lang === 'ar';

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'فشل تسجيل الدخول');
      }
      onLoginSuccess(data.token);
    } catch (err: any) {
      setError(err.message || 'بيانات الدخول غير صحيحة');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-slate-800 border border-slate-700/80 rounded-3xl p-8 shadow-2xl space-y-8">
        <div className="text-center space-y-3">
          <button onClick={onBackToHome} className="inline-flex items-center gap-1.5 text-xs text-teal-400 hover:text-teal-300 font-medium mb-2">
            <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
            <span>{isAr ? 'العودة للموقع الرئيسي' : 'Back to Website'}</span>
          </button>
          <div className="w-14 h-14 bg-teal-700/30 text-teal-400 rounded-2xl flex items-center justify-center mx-auto border border-teal-500/30">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-white font-serif">
            {getTranslation(lang, 'adminLoginTitle')}
          </h2>
          <p className="text-xs text-slate-400">
            {isAr ? 'منطقة مخصصة لإدارة عيادة ابتسامة والمواعيد' : 'Authorized Personnel Only'}
          </p>
        </div>

        {error && (
          <div className="p-4 bg-red-950/60 border border-red-800 text-red-300 text-xs rounded-xl flex items-center gap-3">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-5">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-teal-400" />
              <span>{getTranslation(lang, 'adminEmail')}</span>
            </label>
            <input
              type="email"
              required
              dir="ltr"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 text-start"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-teal-400" />
              <span>{getTranslation(lang, 'adminPassword')}</span>
            </label>
            <input
              type="password"
              required
              dir="ltr"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 text-start"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white font-semibold rounded-xl shadow-lg transition-all text-sm"
          >
            {loading ? (isAr ? 'جاري التحقق...' : 'Signing in...') : getTranslation(lang, 'loginButton')}
          </button>
        </form>

        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-700/50 text-xs text-slate-400 space-y-1 text-center">
          <p className="font-semibold text-slate-300">بيانات الدخول الافتراضية:</p>
          <p dir="ltr">admin@ibtisama.com / admin123</p>
        </div>
      </div>
    </div>
  );
}
