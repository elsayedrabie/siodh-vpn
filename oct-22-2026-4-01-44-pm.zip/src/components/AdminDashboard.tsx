import React, { useEffect, useState } from 'react';
import { Language, Appointment, Branch, Service, GalleryImage } from '../types';
import { getTranslation } from '../i18n';
import { LayoutDashboard, Calendar, MapPin, Stethoscope, Image as ImageIcon, Settings, LogOut, CheckCircle, XCircle, Clock, Trash2, Edit, Plus, AlertCircle, RefreshCw } from 'lucide-react';

interface AdminDashboardProps {
  lang: Language;
  onLogout: () => void;
  onBackToHome: () => void;
}

export default function AdminDashboard({ lang, onLogout, onBackToHome }: AdminDashboardProps) {
  const [tab, setTab] = useState<'overview' | 'appointments' | 'branches' | 'services' | 'gallery'>('overview');
  const [stats, setStats] = useState<any>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [gallery, setGallery] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem('adminToken') || '';

  const fetchData = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [statsRes, apptsRes, branchesRes, servicesRes, galleryRes] = await Promise.all([
        fetch('/api/admin/stats', { headers }),
        fetch('/api/admin/appointments', { headers }),
        fetch('/api/admin/branches', { headers }),
        fetch('/api/admin/services', { headers }),
        fetch('/api/admin/gallery', { headers })
      ]);

      if (statsRes.ok) setStats(await statsRes.json());
      if (apptsRes.ok) setAppointments(await apptsRes.json());
      if (branchesRes.ok) setBranches(await branchesRes.json());
      if (servicesRes.ok) setServices(await servicesRes.json());
      if (galleryRes.ok) setGallery(await galleryRes.json());
    } catch (e) {
      console.error('Error fetching admin data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const updateAppointmentStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/admin/appointments/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ status })
      });
      if (res.ok) fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const deleteAppointment = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الموعد؟')) return;
    try {
      const res = await fetch(`/api/admin/appointments/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const isAr = lang === 'ar';

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col lg:flex-row">
      {/* Sidebar */}
      <aside className="w-full lg:w-72 bg-slate-900 text-slate-300 flex flex-col justify-between p-6 shrink-0">
        <div className="space-y-8">
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-white font-serif">ابتسامة - الإدارة</h2>
            <p className="text-xs text-teal-400">دكتور فؤاد أحمد برعاص</p>
          </div>

          <nav className="space-y-2">
            <button
              onClick={() => setTab('overview')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${tab === 'overview' ? 'bg-teal-700 text-white shadow-md' : 'hover:bg-slate-800 text-slate-300'}`}
            >
              <LayoutDashboard className="w-5 h-5" />
              <span>{getTranslation(lang, 'adminOverview')}</span>
            </button>

            <button
              onClick={() => setTab('appointments')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${tab === 'appointments' ? 'bg-teal-700 text-white shadow-md' : 'hover:bg-slate-800 text-slate-300'}`}
            >
              <Calendar className="w-5 h-5" />
              <span>{getTranslation(lang, 'adminAppointments')}</span>
            </button>

            <button
              onClick={() => setTab('branches')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${tab === 'branches' ? 'bg-teal-700 text-white shadow-md' : 'hover:bg-slate-800 text-slate-300'}`}
            >
              <MapPin className="w-5 h-5" />
              <span>{getTranslation(lang, 'adminBranches')}</span>
            </button>

            <button
              onClick={() => setTab('services')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${tab === 'services' ? 'bg-teal-700 text-white shadow-md' : 'hover:bg-slate-800 text-slate-300'}`}
            >
              <Stethoscope className="w-5 h-5" />
              <span>{getTranslation(lang, 'adminServices')}</span>
            </button>

            <button
              onClick={() => setTab('gallery')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${tab === 'gallery' ? 'bg-teal-700 text-white shadow-md' : 'hover:bg-slate-800 text-slate-300'}`}
            >
              <ImageIcon className="w-5 h-5" />
              <span>{getTranslation(lang, 'adminGallery')}</span>
            </button>
          </nav>
        </div>

        <div className="pt-6 border-t border-slate-800 space-y-3">
          <button
            onClick={onBackToHome}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors text-center block"
          >
            {isAr ? 'عرض الموقع الرئيسي' : 'View Public Website'}
          </button>
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-red-950/60 hover:bg-red-900/60 text-red-300 text-xs font-semibold rounded-xl transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>{getTranslation(lang, 'logoutButton')}</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 lg:p-10 overflow-y-auto">
        <div className="max-w-6xl mx-auto space-y-8">
          
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-slate-900 font-serif">
              {tab === 'overview' && getTranslation(lang, 'adminOverview')}
              {tab === 'appointments' && getTranslation(lang, 'adminAppointments')}
              {tab === 'branches' && getTranslation(lang, 'adminBranches')}
              {tab === 'services' && getTranslation(lang, 'adminServices')}
              {tab === 'gallery' && getTranslation(lang, 'adminGallery')}
            </h1>
            <button
              onClick={fetchData}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors shadow-xs"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>تحديث البيانات</span>
            </button>
          </div>

          {loading ? (
            <div className="text-center py-20 text-slate-500">جاري تحميل لوحة التحكم...</div>
          ) : (
            <>
              {/* Overview Tab */}
              {tab === 'overview' && stats && (
                <div className="space-y-8">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                      <span className="text-xs text-slate-500 font-medium">إجمالي المواعيد</span>
                      <span className="block text-3xl font-extrabold text-slate-900 font-mono">{stats.total}</span>
                    </div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                      <span className="text-xs text-amber-600 font-medium">في انتظار التأكيد</span>
                      <span className="block text-3xl font-extrabold text-amber-600 font-mono">{stats.pending}</span>
                    </div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                      <span className="text-xs text-emerald-600 font-medium">المواعيد المؤكدة</span>
                      <span className="block text-3xl font-extrabold text-emerald-600 font-mono">{stats.confirmed}</span>
                    </div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
                      <span className="text-xs text-teal-600 font-medium">مواعيد اليوم</span>
                      <span className="block text-3xl font-extrabold text-teal-600 font-mono">{stats.todayCount}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Appointments Tab */}
              {tab === 'appointments' && (
                <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-right border-collapse text-sm">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-700">
                          <th className="p-4">المريض</th>
                          <th className="p-4">رقم الهاتف</th>
                          <th className="p-4">التاريخ والوقت</th>
                          <th className="p-4">الحالة</th>
                          <th className="p-4 text-center">الإجراءات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {appointments.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="p-8 text-center text-slate-500">لا توجد مواعيد مسجلة حتى الآن.</td>
                          </tr>
                        ) : (
                          appointments.map((apt) => (
                            <tr key={apt.id} className="hover:bg-slate-50/50">
                              <td className="p-4 font-bold text-slate-900">{apt.patientName}</td>
                              <td className="p-4 font-mono text-slate-600" dir="ltr">{apt.patientPhone}</td>
                              <td className="p-4 text-slate-600 font-mono">
                                {apt.appointmentDate} <span className="text-teal-700 font-bold">({apt.startTime})</span>
                              </td>
                              <td className="p-4">
                                <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                                  apt.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-800' :
                                  apt.status === 'Pending' ? 'bg-amber-100 text-amber-800' :
                                  apt.status === 'Completed' ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800'
                                }`}>
                                  {apt.status}
                                </span>
                              </td>
                              <td className="p-4 text-center space-x-2 rtl:space-x-reverse">
                                <button
                                  onClick={() => updateAppointmentStatus(apt.id, 'Confirmed')}
                                  title="تأكيد"
                                  className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg transition-colors"
                                >
                                  <CheckCircle className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => updateAppointmentStatus(apt.id, 'Cancelled')}
                                  title="إلغاء"
                                  className="p-1.5 bg-red-50 text-red-700 hover:bg-red-100 rounded-lg transition-colors"
                                >
                                  <XCircle className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => deleteAppointment(apt.id)}
                                  title="حذف"
                                  className="p-1.5 bg-slate-100 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Branches Tab */}
              {tab === 'branches' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {branches.map(b => (
                      <div key={b.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                        <h3 className="text-lg font-bold text-slate-900">{b.nameAr}</h3>
                        <p className="text-sm text-slate-600">{b.addressAr}</p>
                        <p className="text-sm font-mono font-semibold text-teal-700" dir="ltr">{b.phone}</p>
                        <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-semibold ${b.isVerified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                          {b.isVerified ? 'معتمد' : 'قيد التأكيد'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Services Tab */}
              {tab === 'services' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {services.map(s => (
                    <div key={s.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                      <h3 className="font-bold text-slate-900">{s.nameAr}</h3>
                      <p className="text-xs text-slate-600 line-clamp-2">{s.descAr}</p>
                      <span className="text-xs font-bold text-teal-700 block">{s.price}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Gallery Tab */}
              {tab === 'gallery' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {gallery.map(img => (
                    <div key={img.id} className="bg-white rounded-xl overflow-hidden border border-slate-200 shadow-xs">
                      <img src={img.imageUrl} alt={img.altAr} className="w-full h-40 object-cover" referrerPolicy="no-referrer" />
                      <div className="p-3 text-xs font-medium text-slate-700">{img.altAr}</div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

        </div>
      </main>
    </div>
  );
}
