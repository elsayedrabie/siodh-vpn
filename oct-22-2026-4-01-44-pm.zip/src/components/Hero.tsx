import React from 'react';
import { Language } from '../types';
import { getTranslation } from '../i18n';
import { Calendar, ArrowRight, Shield, Award, Smile } from 'lucide-react';

interface HeroProps {
  lang: Language;
  onOpenBooking: () => void;
  onExploreServices: () => void;
}

export default function Hero({ lang, onOpenBooking, onExploreServices }: HeroProps) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-teal-50/50 via-white to-white py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Text Content */}
          <div className="lg:col-span-7 space-y-8 text-start">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-100/80 text-teal-800 text-xs font-semibold tracking-wide">
              <Smile className="w-4 h-4 text-teal-700" />
              <span>{getTranslation(lang, 'brandSubtitle')}</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight font-serif leading-[1.2] balance">
              {getTranslation(lang, 'heroTitle')}
            </h1>

            <p className="text-lg text-slate-600 max-w-2xl leading-relaxed">
              {getTranslation(lang, 'heroSubtitle')}
            </p>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={onOpenBooking}
                className="flex items-center justify-center gap-2 px-8 py-4 bg-teal-700 hover:bg-teal-800 text-white font-semibold rounded-xl shadow-lg shadow-teal-700/25 transition-all text-base"
              >
                <Calendar className="w-5 h-5" />
                <span>{getTranslation(lang, 'bookAppointment')}</span>
              </button>

              <button
                onClick={onExploreServices}
                className="flex items-center justify-center gap-2 px-8 py-4 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl transition-all text-base"
              >
                <span>{getTranslation(lang, 'exploreServices')}</span>
                <ArrowRight className="w-5 h-5 rtl:rotate-180" />
              </button>
            </div>

            {/* Key Trust Stats / Highlights */}
            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-slate-200">
              <div>
                <span className="block text-2xl font-bold text-slate-900 font-mono">100%</span>
                <span className="text-xs text-slate-500 font-medium">رعاية شخصية</span>
              </div>
              <div>
                <span className="block text-2xl font-bold text-slate-900 font-mono">أحدث</span>
                <span className="text-xs text-slate-500 font-medium">تقنيات التعقيم</span>
              </div>
              <div>
                <span className="block text-2xl font-bold text-slate-900 font-mono">خبرة</span>
                <span className="text-xs text-slate-500 font-medium">جراحة وتجميل الأسنان</span>
              </div>
            </div>

          </div>

          {/* Right Image Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              <div className="absolute -inset-4 bg-gradient-to-tr from-teal-200 to-teal-50 rounded-3xl -z-10 transform rotate-1"></div>
              <img
                src="https://images.unsplash.com/photo-1629909615184-74f495363b67?auto=format&fit=crop&w=1000&q=80"
                alt="Ibtisama Dental Clinic"
                className="rounded-2xl shadow-xl w-full object-cover h-[420px]"
              />
              <div className="absolute -bottom-6 -start-6 bg-white p-4 rounded-2xl shadow-xl border border-slate-100 flex items-center gap-4">
                <div className="w-12 h-12 bg-teal-50 rounded-xl flex items-center justify-center text-teal-700">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">دكتور فؤاد أحمد برعاص</h4>
                  <p className="text-xs text-slate-500">استشاري جراحة وتجميل الأسنان</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
