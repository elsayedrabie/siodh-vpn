/**
 * Cloudflare Pages Function for handling appointments on Cloudflare
 */

interface Env {
  // Bindings if using Cloudflare D1 or KV
  DB?: any;
}

export async function onRequestPost(context: { request: Request; env: Env }) {
  try {
    const body = await context.request.json() as any;
    const { patientName, patientPhone, branchId, serviceId, appointmentDate, startTime, patientMessage, privacyConsent } = body;

    if (!patientName || !patientPhone || !branchId || !serviceId || !appointmentDate || !startTime) {
      return new Response(JSON.stringify({ error: 'جميع الحقول الأساسية مطلوبة.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (!privacyConsent) {
      return new Response(JSON.stringify({ error: 'يجب الموافقة على سياسة الخصوصية للمتابعة.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // In Cloudflare D1 or KV environment, you would insert into D1 here.
    // For static/serverless deployment demonstration, we return success response.
    const newAppointment = {
      id: 'apt-' + Date.now(),
      patientName,
      patientPhone,
      branchId,
      serviceId,
      appointmentDate,
      startTime,
      status: 'Pending',
      patientMessage: patientMessage || '',
      privacyConsent: true,
      createdAt: new Date().toISOString()
    };

    return new Response(JSON.stringify({ success: true, message: 'تم استلام طلب الموعد بنجاح.', appointment: newAppointment }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message || 'حدث خطأ غير متوقع' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
