var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_url = require("url");
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_meta = {};
import_dotenv.default.config();
var __filename = (0, import_url.fileURLToPath)(import_meta.url);
var __dirname = import_path.default.dirname(__filename);
var app = (0, import_express.default)();
app.use(import_express.default.json());
var sessions = /* @__PURE__ */ new Map();
var DATA_DIR = import_path.default.join(__dirname, "data");
var DB_FILE = import_path.default.join(DATA_DIR, "clinic.json");
if (!import_fs.default.existsSync(DATA_DIR)) {
  import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
}
function hashPassword(password) {
  return import_crypto.default.createHash("sha256").update(password).digest("hex");
}
var defaultDb = {
  users: [
    {
      id: "admin-1",
      email: process.env.ADMIN_EMAIL || "admin@ibtisama.com",
      passwordHash: hashPassword(process.env.ADMIN_PASSWORD || "admin123"),
      role: "admin",
      displayName: "\u062F\u0643\u062A\u0648\u0631 \u0641\u0624\u0627\u062F \u0623\u062D\u0645\u062F \u0628\u0631\u0639\u0627\u0635"
    }
  ],
  branches: [
    {
      id: "branch-qutur",
      nameAr: "\u0641\u0631\u0639 \u0642\u0637\u0648\u0631 (\u0627\u0644\u0631\u0626\u064A\u0633\u064A)",
      nameEn: "Qutur Branch (Main)",
      addressAr: "\u0645\u064A\u062F\u0627\u0646 \u0627\u0644\u0633\u0627\u0639\u0629\u060C \u0642\u0637\u0648\u0631 - \u0637\u0646\u0637\u0627\u060C \u0645\u062F\u064A\u0646\u0629 \u0642\u0637\u0648\u0631\u060C \u0645\u062D\u0627\u0641\u0638\u0629 \u0627\u0644\u063A\u0631\u0628\u064A\u0629",
      addressEn: "Al-Saa Square, Qutur - Tanta, Gharbia Governorate",
      city: "\u0642\u0637\u0648\u0631",
      goverrorate: "\u0627\u0644\u063A\u0631\u0628\u064A\u0629",
      phone: "01129207375",
      whatsapp: "201129207375",
      googleMapsUrl: "https://maps.google.com/?q=Qutur+Gharbia+Egypt",
      openingHours: "\u0627\u0644\u0633\u0628\u062A - \u0627\u0644\u062E\u0645\u064A\u0633: 1:00 \u0638\u0647\u0631\u0627\u064B - 10:00 \u0645\u0633\u0627\u0621\u064B (\u0627\u0644\u062C\u0645\u0639\u0629 \u0645\u063A\u0644\u0642)",
      isActive: true,
      isVerified: true
    },
    {
      id: "branch-damietta",
      nameAr: "\u0641\u0631\u0639 \u062F\u0645\u064A\u0627\u0637",
      nameEn: "Damietta Branch",
      addressAr: "\u062F\u0645\u064A\u0627\u0637 - \u0643\u0648\u0631\u0646\u064A\u0634 \u0627\u0644\u0646\u064A\u0644 (\u0642\u064A\u062F \u0627\u0644\u062A\u0623\u0643\u064A\u062F \u0627\u0644\u0646\u0647\u0627\u0626\u064A)",
      addressEn: "Damietta - Nile Corniche (Pending Final Verification)",
      city: "\u062F\u0645\u064A\u0627\u0637",
      goverrorate: "\u062F\u0645\u064A\u0627\u0637",
      phone: "01129207375",
      whatsapp: "201129207375",
      googleMapsUrl: "https://maps.google.com/?q=Damietta+Egypt",
      openingHours: "\u064A\u0648\u0645\u064A\u0627\u064B \u0645\u0627 \u0639\u062F\u0627 \u0627\u0644\u062C\u0645\u0639\u0629 (\u062A\u0648\u0627\u0635\u0644 \u0644\u062A\u0623\u0643\u064A\u062F \u0627\u0644\u0645\u0648\u0627\u0639\u064A\u062F)",
      isActive: true,
      isVerified: false
    }
  ],
  services: [
    {
      id: "srv-implants",
      nameAr: "\u0632\u0631\u0627\u0639\u0629 \u0627\u0644\u0623\u0633\u0646\u0627\u0646",
      nameEn: "Dental Implants",
      nameFr: "Implants Dentaires",
      nameDe: "Zahnimplantate",
      nameTr: "Di\u015F \u0130mplantlar\u0131",
      descAr: "\u062A\u0639\u0648\u064A\u0636 \u0627\u0644\u0623\u0633\u0646\u0627\u0646 \u0627\u0644\u0645\u0641\u0642\u0648\u062F\u0629 \u0628\u062C\u0630\u0648\u0631 \u062A\u064A\u062A\u0627\u0646\u064A\u0648\u0645 \u0645\u062A\u064A\u0646\u0629 \u0648\u0622\u0645\u0646\u0629 \u0648\u0628\u0623\u062D\u062F\u062B \u062A\u0642\u0646\u064A\u0627\u062A \u0627\u0644\u0632\u0631\u0627\u0639\u0629 \u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629.",
      descEn: "Replace missing teeth with durable titanium roots and state-of-the-art implant techniques.",
      descFr: "Remplacez les dents manquantes par des racines en titane durables.",
      descDe: "Ersetzen Sie fehlende Z\xE4hne durch langlebige Titanimplantate.",
      descTr: "Eksik di\u015Fleri dayan\u0131kl\u0131 titanyum k\xF6klerle de\u011Fi\u015Ftirin.",
      imageUrl: "https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=800&q=80",
      price: "\u062A\u0648\u0627\u0635\u0644 \u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0633\u0639\u0631",
      durationMinutes: 60,
      isActive: true,
      displayOrder: 1
    },
    {
      id: "srv-whitening",
      nameAr: "\u062A\u0628\u064A\u064A\u0636 \u0627\u0644\u0623\u0633\u0646\u0627\u0646",
      nameEn: "Teeth Whitening",
      nameFr: "Blanchiment Dentaire",
      nameDe: "Zahnaufhellung",
      nameTr: "Di\u015F Beyazlatma",
      descAr: "\u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0628\u0631\u064A\u0642 \u0648\u0627\u0628\u062A\u0633\u0627\u0645\u0629 \u0628\u064A\u0636\u0627\u0621 \u0646\u0627\u0635\u0639\u0629 \u0628\u0623\u062D\u062F\u062B \u062A\u0642\u0646\u064A\u0627\u062A \u0627\u0644\u0644\u064A\u0632\u0631 \u0627\u0644\u0622\u0645\u0646\u0629 \u0639\u0644\u0649 \u0645\u064A\u0646\u0627\u0621 \u0627\u0644\u0623\u0633\u0646\u0627\u0646.",
      descEn: "Restore your bright white smile using safe, advanced laser whitening technology.",
      descFr: "Retrouvez un sourire \xE9clatant gr\xE2ce au blanchiment laser.",
      descDe: "Stellen Sie Ihr strahlendes L\xE4cheln mit Laserbleaching wieder her.",
      descTr: "Geli\u015Fmi\u015F lazer teknolojisiyle parlak beyaz g\xFCl\xFC\u015F\xFCn\xFCz\xFC geri kazan\u0131n.",
      imageUrl: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80",
      price: "\u062A\u0648\u0627\u0635\u0644 \u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0633\u0639\u0631",
      durationMinutes: 45,
      isActive: true,
      displayOrder: 2
    },
    {
      id: "srv-ortho",
      nameAr: "\u062A\u0642\u0648\u064A\u0645 \u0627\u0644\u0623\u0633\u0646\u0627\u0646",
      nameEn: "Orthodontics",
      nameFr: "Orthodontie",
      nameDe: "Kieferorthop\xE4die",
      nameTr: "Ortodonti",
      descAr: "\u0625\u0635\u0644\u0627\u062D \u0627\u0639\u0648\u062C\u0627\u062C \u0627\u0644\u0623\u0633\u0646\u0627\u0646 \u0648\u062A\u0637\u0627\u0628\u0642 \u0627\u0644\u0625\u0637\u0628\u0627\u0642 \u0644\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0627\u0628\u062A\u0633\u0627\u0645\u0629 \u0645\u062B\u0627\u0644\u064A\u0629 \u0648\u0645\u062B\u0627\u0644\u064A\u0629 \u0627\u0644\u0648\u0638\u064A\u0641\u0629.",
      descEn: "Correct teeth alignment and bite occlusion for a perfectly balanced smile.",
      descFr: "Corrigez l alignement des dents et l occlusion pour un sourire parfait.",
      descDe: "Korrigieren Sie Zahnfehlstellungen f\xFCr ein perfektes L\xE4cheln.",
      descTr: "M\xFCkemmel bir g\xFCl\xFC\u015F i\xE7in di\u015F hizalamas\u0131n\u0131 ve kapan\u0131\u015F\u0131n\u0131 d\xFCzeltin.",
      imageUrl: "https://images.unsplash.com/photo-1598256989800-fe5f95da9787?auto=format&fit=crop&w=800&q=80",
      price: "\u062A\u0648\u0627\u0635\u0644 \u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0633\u0639\u0631",
      durationMinutes: 45,
      isActive: true,
      displayOrder: 3
    },
    {
      id: "srv-rootcanal",
      nameAr: "\u0639\u0644\u0627\u062C \u0648\u062D\u0634\u0648 \u0627\u0644\u0639\u0635\u0628",
      nameEn: "Root Canal Treatment",
      nameFr: "Traitement de Canal",
      nameDe: "Wurzelbehandlung",
      nameTr: "Kanal Tedavisi",
      descAr: "\u0625\u0632\u0627\u0644\u0629 \u0627\u0644\u0627\u0644\u062A\u0647\u0627\u0628\u0627\u062A \u0648\u062A\u062E\u0644\u064A\u0635\u0643 \u0645\u0646 \u0627\u0644\u0623\u0644\u0645 \u0646\u0647\u0627\u0626\u064A\u0627\u064B \u0628\u0623\u062D\u062F\u062B \u0623\u062C\u0647\u0632\u0629 \u0627\u0644\u0631\u0648\u062A\u0627\u0631\u064A \u0648\u0628\u062F\u0648\u0646 \u0623\u0644\u0645.",
      descEn: "Remove infection and eliminate pain with advanced painless rotary endodontics.",
      descFr: "\xC9liminez l infection et la douleur avec des techniques endodontiques modernes.",
      descDe: "Beseitigen Sie Infektionen und Schmerzen mit modernen Endodontie-Ger\xE4ten.",
      descTr: "Geli\u015Fmi\u015F d\xF6ner endodonti cihazlar\u0131yla enfeksiyonu ve a\u011Fr\u0131y\u0131 ortadan kald\u0131r\u0131n.",
      imageUrl: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=800&q=80",
      price: "\u062A\u0648\u0627\u0635\u0644 \u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0633\u0639\u0631",
      durationMinutes: 60,
      isActive: true,
      displayOrder: 4
    },
    {
      id: "srv-fillings",
      nameAr: "\u0627\u0644\u062D\u0634\u0648 \u0627\u0644\u062A\u062C\u0645\u064A\u0644\u064A \u0627\u0644\u0639\u0627\u062F\u064A",
      nameEn: "Regular & Cosmetic Fillings",
      nameFr: "Obturations Esth\xE9tiques",
      nameDe: "\xC4sthetische F\xFCllungen",
      nameTr: "Estetik Dolgular",
      descAr: "\u062D\u0634\u0648\u0627\u062A \u0636\u0648\u0626\u064A\u0629 \u062A\u062C\u0645\u064A\u0644\u064A\u0629 \u0645\u0637\u0627\u0628\u0642\u0629 \u0644\u0644\u0648\u0646 \u0627\u0644\u0623\u0633\u0646\u0627\u0646 \u0627\u0644\u0637\u0628\u064A\u0639\u064A\u0629 \u0644\u0639\u0644\u0627\u062C \u0627\u0644\u062A\u0633\u0648\u0633 \u0648\u0625\u0639\u0627\u062F\u0629 \u062A\u0631\u0645\u064A\u0645 \u0627\u0644\u0633\u0646.",
      descEn: "Tooth-colored composite fillings to repair cavities and restore natural appearance.",
      descFr: "Obturations en composite de la couleur des dents pour r\xE9parer les caries.",
      descDe: "Zahnfarbene Kompositf\xFCllungen zur Kariesbehandlung und Wiederherstellung.",
      descTr: "\xC7\xFCr\xFCkleri tedavi etmek ve do\u011Fal g\xF6r\xFCn\xFCm\xFC geri kazand\u0131rmak i\xE7in kompozit dolgular.",
      imageUrl: "https://images.unsplash.com/photo-1571772996211-2f0c6973722a?auto=format&fit=crop&w=800&q=80",
      price: "\u062A\u0648\u0627\u0635\u0644 \u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0633\u0639\u0631",
      durationMinutes: 30,
      isActive: true,
      displayOrder: 5
    },
    {
      id: "srv-surgery",
      nameAr: "\u062C\u0631\u0627\u062D\u0629 \u0627\u0644\u0641\u0645 \u0648\u0627\u0644\u0623\u0633\u0646\u0627\u0646",
      nameEn: "Oral Surgery",
      nameFr: "Chirurgie Buccale",
      nameDe: "Oralchirurgie",
      nameTr: "A\u011F\u0131z Cerrahisi",
      descAr: "\u062E\u0644\u0639 \u0627\u0644\u0623\u0633\u0646\u0627\u0646 \u0627\u0644\u0645\u0639\u0642\u062F\u0629 \u0648\u062C\u0631\u0627\u062D\u0629 \u0636\u0631\u0633 \u0627\u0644\u0639\u0631\u0633 \u0628\u0645\u0647\u0627\u0631\u0629 \u0648\u0639\u0646\u0627\u064A\u0629 \u0641\u0627\u0626\u0642\u0629 \u0644\u0631\u0627\u062D\u0629 \u0627\u0644\u0645\u0631\u064A\u0636.",
      descEn: "Complex tooth extractions and wisdom tooth surgery with expert care and comfort.",
      descFr: "Extractions dentaires complexes et chirurgie des dents de sagesse.",
      descDe: "Komplexe Zahnextraktionen und Weisheitszahnchirurgie mit fachm\xE4nnischer Sorgfalt.",
      descTr: "Uzman bak\u0131m\u0131 ve konforuyla karma\u015F\u0131k di\u015F \xE7ekimleri ve yirmilik di\u015F cerrahisi.",
      imageUrl: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80",
      price: "\u062A\u0648\u0627\u0635\u0644 \u0644\u0645\u0639\u0631\u0641\u0629 \u0627\u0644\u0633\u0639\u0631",
      durationMinutes: 45,
      isActive: true,
      displayOrder: 6
    }
  ],
  appointments: [],
  gallery: [
    {
      id: "gal-1",
      imageUrl: "https://images.unsplash.com/photo-1629909615184-74f495363b67?auto=format&fit=crop&w=800&q=80",
      altAr: "\u0639\u064A\u0627\u062F\u0629 \u0627\u0644\u0623\u0633\u0646\u0627\u0646 \u0627\u0644\u062D\u062F\u064A\u062B\u0629",
      altEn: "Modern dental clinic room",
      category: "clinic",
      displayOrder: 1,
      isActive: true
    },
    {
      id: "gal-2",
      imageUrl: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80",
      altAr: "\u063A\u0631\u0641\u0629 \u0627\u0644\u0643\u0634\u0641 \u0648\u0627\u0644\u062A\u0639\u0642\u064A\u0645",
      altEn: "Sterilization and examination room",
      category: "clinic",
      displayOrder: 2,
      isActive: true
    },
    {
      id: "gal-3",
      imageUrl: "https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=800&q=80",
      altAr: "\u0623\u062D\u062F\u062B \u0623\u062C\u0647\u0632\u0629 \u0637\u0628 \u0627\u0644\u0623\u0633\u0646\u0627\u0646",
      altEn: "Advanced dental equipment",
      category: "equipment",
      displayOrder: 3,
      isActive: true
    },
    {
      id: "gal-4",
      imageUrl: "https://images.unsplash.com/photo-1571772996211-2f0c6973722a?auto=format&fit=crop&w=800&q=80",
      altAr: "\u0645\u0646\u0637\u0642\u0629 \u0627\u0644\u0627\u0633\u062A\u0642\u0628\u0627\u0644 \u0627\u0644\u0645\u0631\u064A\u062D\u0629",
      altEn: "Comfortable waiting lounge",
      category: "reception",
      displayOrder: 4,
      isActive: true
    }
  ],
  settings: {
    heroTitleAr: "\u0627\u0628\u062A\u0633\u0627\u0645\u062A\u0643 \u062A\u0633\u062A\u062D\u0642 \u0623\u0641\u0636\u0644 \u0639\u0646\u0627\u064A\u0629",
    heroSubtitleAr: "\u0631\u0639\u0627\u064A\u0629 \u0645\u062A\u062E\u0635\u0635\u0629 \u0644\u0623\u0633\u0646\u0627\u0646\u0643 \u0648\u0627\u0628\u062A\u0633\u0627\u0645\u062A\u0643 \u0641\u064A \u0628\u064A\u0626\u0629 \u0645\u0631\u064A\u062D\u0629 \u0648\u0627\u062D\u062A\u0631\u0627\u0641\u064A\u0629 \u0628\u0625\u0634\u0631\u0627\u0641 \u062F\u0643\u062A\u0648\u0631 \u0641\u0624\u0627\u062F \u0623\u062D\u0645\u062F \u0628\u0631\u0639\u0627\u0635.",
    doctorBioBioAr: "\u0627\u0633\u062A\u0634\u0627\u0631\u064A \u062C\u0631\u0627\u062D\u0629 \u0648\u062A\u062C\u0645\u064A\u0644 \u0627\u0644\u0641\u0645 \u0648\u0627\u0644\u0623\u0633\u0646\u0627\u0646\u060C \u0628\u062E\u0628\u0631\u0629 \u0648\u0627\u0633\u0639\u0629 \u0641\u064A \u062A\u062C\u0645\u064A\u0644 \u0648\u0632\u0631\u0627\u0639\u0629 \u0627\u0644\u0623\u0633\u0646\u0627\u0646 \u0648\u0639\u0644\u0627\u062C \u062C\u0630\u0648\u0631 \u0627\u0644\u0623\u0633\u0646\u0627\u0646.",
    announcementAr: "\u0645\u0631\u062D\u0628\u0627\u064B \u0628\u0643\u0645 \u0641\u064A \u0639\u064A\u0627\u062F\u0629 \u0627\u0628\u062A\u0633\u0627\u0645\u0629. \u0627\u062D\u062C\u0632 \u0645\u0648\u0639\u062F\u0643 \u0623\u0648\u0646\u0644\u0627\u064A\u0646 \u0628\u0643\u0644 \u0633\u0647\u0648\u0644\u0629."
  }
};
function loadDb() {
  try {
    if (import_fs.default.existsSync(DB_FILE)) {
      const data = import_fs.default.readFileSync(DB_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (e) {
    console.error("Error loading DB, using default:", e);
  }
  saveDb(defaultDb);
  return defaultDb;
}
function saveDb(db2) {
  try {
    import_fs.default.writeFileSync(DB_FILE, JSON.stringify(db2, null, 2), "utf-8");
  } catch (e) {
    console.error("Error saving DB:", e);
  }
}
var db = loadDb();
app.use((req, res, next) => {
  const authHeader = req.headers.authorization;
  const cookieHeader = req.headers.cookie;
  let sessionId = "";
  if (authHeader && authHeader.startsWith("Bearer ")) {
    sessionId = authHeader.substring(7);
  } else if (cookieHeader) {
    const match = cookieHeader.match(/sessionId=([^;]+)/);
    if (match) sessionId = match[1];
  }
  if (sessionId && sessions.has(sessionId)) {
    const session = sessions.get(sessionId);
    if (session.expiresAt > Date.now()) {
      req.user = session;
    } else {
      sessions.delete(sessionId);
    }
  }
  next();
});
app.get("/api/branches", (req, res) => {
  res.json(db.branches.filter((b) => b.isActive));
});
app.get("/api/services", (req, res) => {
  res.json(db.services.filter((s) => s.isActive).sort((a, b) => a.displayOrder - b.displayOrder));
});
app.get("/api/gallery", (req, res) => {
  res.json(db.gallery.filter((g) => g.isActive).sort((a, b) => a.displayOrder - b.displayOrder));
});
app.get("/api/settings", (req, res) => {
  res.json(db.settings);
});
app.post("/api/appointments", (req, res) => {
  const { patientName, patientPhone, branchId, serviceId, appointmentDate, startTime, patientMessage, privacyConsent } = req.body;
  if (!patientName || !patientPhone || !branchId || !serviceId || !appointmentDate || !startTime) {
    return res.status(400).json({ error: "\u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0642\u0648\u0644 \u0627\u0644\u0623\u0633\u0627\u0633\u064A\u0629 \u0645\u0637\u0644\u0648\u0628\u0629." });
  }
  if (!privacyConsent) {
    return res.status(400).json({ error: "\u064A\u062C\u0628 \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0639\u0644\u0649 \u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629 \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629." });
  }
  const conflict = db.appointments.find(
    (app2) => app2.branchId === branchId && app2.appointmentDate === appointmentDate && app2.startTime === startTime && app2.status !== "Cancelled"
  );
  if (conflict) {
    return res.status(409).json({ error: "\u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0639\u062F \u0645\u062D\u062C\u0648\u0632 \u0645\u0633\u0628\u0642\u0627\u064B. \u064A\u0631\u062C\u0649 \u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u0648\u0639\u062F \u0622\u062E\u0631." });
  }
  const service = db.services.find((s) => s.id === serviceId);
  const duration = service ? service.durationMinutes : 30;
  const [hours, mins] = startTime.split(":").map(Number);
  const endTotalMins = hours * 60 + mins + duration;
  const endHours = Math.floor(endTotalMins / 60) % 24;
  const endMins = endTotalMins % 60;
  const endTime = `${String(endHours).padStart(2, "0")}:${String(endMins).padStart(2, "0")}`;
  const newAppt = {
    id: "apt-" + Date.now() + "-" + Math.floor(Math.random() * 1e3),
    patientName,
    patientPhone,
    branchId,
    serviceId,
    appointmentDate,
    startTime,
    endTime,
    status: "Pending",
    patientMessage: patientMessage || "",
    privacyConsent: Boolean(privacyConsent),
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.appointments.push(newAppt);
  saveDb(db);
  res.status(201).json({ success: true, message: "\u062A\u0645 \u0627\u0633\u062A\u0644\u0627\u0645 \u0637\u0644\u0628 \u0627\u0644\u0645\u0648\u0639\u062F \u0628\u0646\u062C\u0627\u062D. \u0633\u0646\u0642\u0648\u0645 \u0628\u062A\u0623\u0643\u064A\u062F \u0645\u0648\u0639\u062F\u0643 \u0642\u0631\u064A\u0628\u0627\u064B.", appointment: newAppt });
});
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0648\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0645\u0637\u0644\u0648\u0628\u0627\u0646." });
  }
  const passHash = hashPassword(password);
  const user = db.users.find((u) => u.email.toLowerCase() === email.toLowerCase() && u.passwordHash === passHash);
  if (!user) {
    return res.status(401).json({ error: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D\u0629." });
  }
  const sessionId = import_crypto.default.randomBytes(32).toString("hex");
  sessions.set(sessionId, {
    userId: user.id,
    role: user.role,
    email: user.email,
    expiresAt: Date.now() + 24 * 60 * 60 * 1e3
    // 24 hours
  });
  res.setHeader("Set-Cookie", `sessionId=${sessionId}; Path=/; HttpOnly; SameSite=Strict`);
  res.json({ success: true, token: sessionId, user: { email: user.email, role: user.role, displayName: user.displayName } });
});
app.post("/api/auth/logout", (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    sessions.delete(authHeader.substring(7));
  }
  res.setHeader("Set-Cookie", "sessionId=; Path=/; Max-Age=0");
  res.json({ success: true });
});
app.get("/api/auth/me", (req, res) => {
  const user = req.user;
  if (!user) {
    return res.status(401).json({ error: "\u063A\u064A\u0631 \u0645\u0633\u062C\u0644 \u0627\u0644\u062F\u062E\u0648\u0644" });
  }
  const dbUser = db.users.find((u) => u.id === user.userId);
  res.json({ email: user.email, role: user.role, displayName: dbUser?.displayName || "\u0645\u0633\u0624\u0648\u0644 \u0627\u0644\u0646\u0638\u0627\u0645" });
});
function requireAdmin(req, res, next) {
  const user = req.user;
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0644\u0643 \u0628\u0627\u0644\u0648\u0635\u0648\u0644 \u0644\u0647\u0630\u0647 \u0627\u0644\u0645\u0646\u0637\u0642\u0629." });
  }
  next();
}
app.get("/api/admin/stats", requireAdmin, (req, res) => {
  const total = db.appointments.length;
  const pending = db.appointments.filter((a) => a.status === "Pending").length;
  const confirmed = db.appointments.filter((a) => a.status === "Confirmed").length;
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const todayCount = db.appointments.filter((a) => a.appointmentDate === today).length;
  const cancelled = db.appointments.filter((a) => a.status === "Cancelled").length;
  const branchStats = db.branches.map((b) => ({
    branchId: b.id,
    branchName: b.nameAr,
    count: db.appointments.filter((a) => a.branchId === b.id).length
  }));
  res.json({
    total,
    pending,
    confirmed,
    todayCount,
    cancelled,
    branchStats
  });
});
app.get("/api/admin/appointments", requireAdmin, (req, res) => {
  res.json(db.appointments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
});
app.put("/api/admin/appointments/:id", requireAdmin, (req, res) => {
  const { id } = req.params;
  const { status, privateAdminNotes } = req.body;
  const appt = db.appointments.find((a) => a.id === id);
  if (!appt) {
    return res.status(404).json({ error: "\u0627\u0644\u0645\u0648\u0639\u062F \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F." });
  }
  if (status) appt.status = status;
  if (privateAdminNotes !== void 0) appt.privateAdminNotes = privateAdminNotes;
  saveDb(db);
  res.json({ success: true, appointment: appt });
});
app.delete("/api/admin/appointments/:id", requireAdmin, (req, res) => {
  const { id } = req.params;
  db.appointments = db.appointments.filter((a) => a.id !== id);
  saveDb(db);
  res.json({ success: true });
});
app.get("/api/admin/branches", requireAdmin, (req, res) => {
  res.json(db.branches);
});
app.post("/api/admin/branches", requireAdmin, (req, res) => {
  const newBranch = {
    id: "branch-" + Date.now(),
    ...req.body
  };
  db.branches.push(newBranch);
  saveDb(db);
  res.status(201).json({ success: true, branch: newBranch });
});
app.put("/api/admin/branches/:id", requireAdmin, (req, res) => {
  const { id } = req.params;
  const idx = db.branches.findIndex((b) => b.id === id);
  if (idx === -1) return res.status(404).json({ error: "\u0627\u0644\u0641\u0631\u0639 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F." });
  db.branches[idx] = { ...db.branches[idx], ...req.body, id };
  saveDb(db);
  res.json({ success: true, branch: db.branches[idx] });
});
app.delete("/api/admin/branches/:id", requireAdmin, (req, res) => {
  const { id } = req.params;
  db.branches = db.branches.filter((b) => b.id !== id);
  saveDb(db);
  res.json({ success: true });
});
app.get("/api/admin/services", requireAdmin, (req, res) => {
  res.json(db.services);
});
app.post("/api/admin/services", requireAdmin, (req, res) => {
  const newService = {
    id: "srv-" + Date.now(),
    ...req.body
  };
  db.services.push(newService);
  saveDb(db);
  res.status(201).json({ success: true, service: newService });
});
app.put("/api/admin/services/:id", requireAdmin, (req, res) => {
  const { id } = req.params;
  const idx = db.services.findIndex((s) => s.id === id);
  if (idx === -1) return res.status(404).json({ error: "\u0627\u0644\u062E\u062F\u0645\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629." });
  db.services[idx] = { ...db.services[idx], ...req.body, id };
  saveDb(db);
  res.json({ success: true, service: db.services[idx] });
});
app.delete("/api/admin/services/:id", requireAdmin, (req, res) => {
  const { id } = req.params;
  db.services = db.services.filter((s) => s.id !== id);
  saveDb(db);
  res.json({ success: true });
});
app.get("/api/admin/gallery", requireAdmin, (req, res) => {
  res.json(db.gallery);
});
app.post("/api/admin/gallery", requireAdmin, (req, res) => {
  const item = {
    id: "gal-" + Date.now(),
    ...req.body
  };
  db.gallery.push(item);
  saveDb(db);
  res.status(201).json({ success: true, item });
});
app.delete("/api/admin/gallery/:id", requireAdmin, (req, res) => {
  const { id } = req.params;
  db.gallery = db.gallery.filter((g) => g.id !== id);
  saveDb(db);
  res.json({ success: true });
});
app.get("/api/admin/settings", requireAdmin, (req, res) => {
  res.json(db.settings);
});
app.put("/api/admin/settings", requireAdmin, (req, res) => {
  db.settings = { ...db.settings, ...req.body };
  saveDb(db);
  res.json({ success: true, settings: db.settings });
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true }
    });
    app.use(vite.middlewares);
  } else {
    app.use(import_express.default.static(import_path.default.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(__dirname, "dist", "index.html"));
    });
  }
  const PORT = process.env.PORT || 3e3;
  app.listen(PORT, () => {
    console.log(`Ibtisama Dental Clinic server running on http://localhost:${PORT}`);
  });
}
startServer();
